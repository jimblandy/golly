-- h-to-h-collection-21Aug2017.lua
-- Useful links for online collections related to Herschel conduits

local g = golly()

htmlname = g.getdir("temp").."h-to-h-collection-21Aug2017.html"
f = io.open(htmlname, "w")
if f then
    f:write(
[[
<html>
<title>Handy Helpful Herschel links</title>
<body bgcolor="#FFFFCE">

<p>
This collection of small Herschel conduits is maintained online, at <a href="http://conwaylife.com/forums/viewtopic.php?f=2&t=2347&p=34533#p34533">a thread on the conwaylife.com forums</a>.<br />The online collection may contain new discoveries not shown here.<br /><br />

For a summary of the naming conventions and statistics in the stamp collection's labels, see Pattern Info.<br /><br />

Other useful discussion threads and articles on <a href="http://www.conwaylife.com">http://www.conwaylife.com</a> include:<br /><br />

* <a href="http://conwaylife.com/wiki/Conduit">LifeWiki article on <b>B3/S23 Herschel conduits</b></a><br /><br />

* <a href="http://conwaylife.com/forums/viewtopic.php?f=2&t=1599">aggregation thread for <b>new Herschel conduits</b></a><br /><br />

* <a href="http://conwaylife.com/forums/viewtopic.php?f=2&t=1097">aggregation thread for <b>period multipliers</b></a><br /><br />

* <a href="http://conwaylife.com/forums/viewtopic.php?f=2&t=1682"><b>H-to-G and H-to-2G</b> converter collection</a> and <a href="http://conwaylife.com/forums/viewtopic.php?f=2&t=1682"><b>glider pair adjustment toolkit</b> thread</a><br />
<i>(useful for producing precisely timed signals,<br />
including multiple synchronized outputs from one input signal)</i><br /><br />

* <a href="http://conwaylife.com/forums/viewtopic.php?f=2&t=1599">aggregation thread for <b>still life factories</b></a><br />
<i>(useful for building or rebuilding bait objects, constructing one-time turners, etc.)</i><br /><br />

* <a href="http://conwaylife.com/forums/viewtopic.php?f=2&t=1849">aggregation thread for new <b>elementary conduits</b></a><br />
<i>(the small H-to-H conduits are built from these elementary conduits,<br />
by adding the restriction that the signal must start as a Herschel and end with a Herschel)</i>
</body>
</html>
]]
    )
    f:close()
end
g.open(htmlname)

