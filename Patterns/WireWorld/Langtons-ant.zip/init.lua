local g = golly()

-- switch scale to 1:1 and turn off auto-fit option so scale won't
-- change when pattern starts generating
g.setmag(0)
g.setoption("autofit",0)

-- ensure the colors of states 0 and 3 are similar to make it
-- easier to see the ant move and leave its droppings
g.setcolors({0,  48,  48,  48,   -- dark gray
             1,   0, 128, 255,   -- light blue
             2, 255, 255, 255,   -- white
             3, 100,  50,   0})  -- dark brown

-- set the initial step to 28^1 to avoid becoming dizzy watching
-- electrons cycle around the interior
g.setbase(28)
g.setstep(1)
