local g = golly()
rulename = g.getdir("rules").."RainbowASOv1.3.rule"
f = io.open(rulename, "w")
if f then
    f:write(
[[
@RULE RainbowASOv1.3
@TABLE
n_states:36
neighborhood:Moore
symmetries:rotate4reflect
var aa=1
var ab=2
var ac=3
var ad=4
var ae=5
var af=6
var ag=7
var ah=8 
var ai=9 
var aj=10
var ak=11
var al=12
var am=13
var an=14
var ao=15
var ap=16
var aq=17
var ar=18
var as=19
var at=20
var au=21
var av=22
var aw=23
var za=24
var zb=25
var zd=26
var zf=27
var zi=28
var zk=29
var zl=30
var zm=31
var zo=32
var zp=33
var zs=34
var zz=35
var a={0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35}
var b=a
var d=a
var e=a
var f=a
var g=a
var i=a
var j=a
var k=a
#life
0,aa,aa,aa,0,0,0,0,0,aa
0,aa,aa,0,aa,0,0,0,0,aa
0,aa,aa,0,0,aa,0,0,0,aa
0,aa,aa,0,0,0,aa,0,0,aa
0,aa,aa,0,0,0,0,aa,0,aa
0,aa,aa,0,0,0,0,0,aa,aa
0,aa,0,aa,0,aa,0,0,0,aa
0,aa,0,aa,0,0,aa,0,0,aa
0,aa,0,0,aa,0,aa,0,0,aa
0,0,aa,0,aa,0,aa,0,0,aa
aa,aa,aa,0,0,0,0,0,0,aa
aa,aa,0,aa,0,0,0,0,0,aa
aa,aa,0,0,aa,0,0,0,0,aa
aa,aa,0,0,0,aa,0,0,0,aa
aa,0,aa,0,aa,0,0,0,0,aa
aa,0,aa,0,0,aa,0,0,0,aa
aa,0,aa,0,0,0,aa,0,0,aa
aa,aa,aa,aa,0,0,0,0,0,aa
aa,aa,aa,0,aa,0,0,0,0,aa
aa,aa,aa,0,0,aa,0,0,0,aa
aa,aa,aa,0,0,0,aa,0,0,aa
aa,aa,aa,0,0,0,0,aa,0,aa
aa,aa,aa,0,0,0,0,0,aa,aa
aa,aa,0,aa,0,aa,0,0,0,aa
aa,aa,0,aa,0,0,aa,0,0,aa
aa,aa,0,0,aa,0,aa,0,0,aa
aa,0,aa,0,aa,0,aa,0,0,aa
#c1
0,ab,ab,0,0,0,0,0,0,ab
0,ab,ab,0,0,ab,0,0,0,ab
#c9
0,ac,0,0,ac,0,0,0,0,ac
0,ac,0,0,0,ac,0,0,0,ac
0,ac,ac,ac,0,0,0,0,0,ac
0,ac,ac,0,ac,0,0,0,0,ac
0,ac,ac,0,0,ac,0,0,0,ac
0,ac,ac,0,0,0,ac,0,0,ac
0,ac,ac,0,0,0,0,ac,0,ac
0,ac,ac,0,0,0,0,0,ac,ac
0,ac,0,ac,0,ac,0,0,0,ac
0,ac,0,ac,0,0,ac,0,0,ac
0,ac,0,0,ac,0,ac,0,0,ac
0,0,ac,0,ac,0,ac,0,0,ac
0,ac,ac,0,ac,ac,0,0,0,ac
ac,ac,0,0,0,0,0,0,0,ac
ac,0,ac,0,0,0,0,0,0,ac
ac,ac,ac,ac,0,0,0,0,0,ac
ac,ac,ac,0,ac,0,0,0,0,ac
ac,ac,ac,0,0,ac,0,0,0,ac
ac,ac,ac,0,0,0,ac,0,0,ac
ac,ac,ac,0,0,0,0,ac,0,ac
ac,ac,ac,0,0,0,0,0,ac,ac
ac,ac,0,ac,0,0,ac,0,0,ac
ac,ac,0,0,ac,0,ac,0,0,ac
ac,0,ac,0,ac,0,ac,0,0,ac
#c11
0,ad,ad,0,0,0,0,0,0,ad
0,ad,0,ad,0,0,0,0,0,ad
0,ad,0,0,ad,0,0,0,0,ad
0,ad,0,0,0,ad,0,0,0,ad
0,0,ad,0,ad,0,0,0,0,ad
0,0,ad,0,0,0,ad,0,0,ad
0,ad,ad,ad,ad,0,0,0,0,ad
0,ad,ad,ad,0,ad,0,0,0,ad
0,ad,ad,ad,0,0,ad,0,0,ad
0,ad,ad,0,ad,ad,0,0,0,ad
0,ad,ad,0,ad,0,ad,0,0,ad
0,ad,ad,0,ad,0,0,ad,0,ad
0,ad,ad,0,ad,0,0,0,ad,ad
0,ad,ad,0,0,ad,ad,0,0,ad
0,ad,ad,0,0,ad,0,ad,0,ad
0,ad,ad,0,0,ad,0,0,ad,ad
0,ad,ad,0,0,0,ad,ad,0,ad
0,ad,0,ad,0,ad,0,ad,0,ad
0,0,ad,0,ad,0,ad,0,ad,ad
ad,0,0,0,0,0,0,0,0,ad
ad,ad,ad,0,0,0,0,0,0,ad
ad,ad,0,ad,0,0,0,0,0,ad
ad,ad,0,0,ad,0,0,0,0,ad
ad,ad,0,0,0,ad,0,0,0,ad
ad,0,ad,0,ad,0,0,0,0,ad
ad,0,ad,0,0,0,ad,0,0,ad
#c13
0,0,ae,0,0,0,ae,0,0,ae
0,ae,ae,ae,0,0,0,0,0,ae
0,ae,ae,0,0,ae,0,0,0,ae
0,ae,ae,0,0,0,ae,0,0,ae
0,ae,ae,0,0,0,0,0,ae,ae
0,ae,0,ae,0,ae,0,0,0,ae
0,ae,0,ae,0,0,ae,0,0,ae
0,ae,0,0,ae,0,ae,0,0,ae
0,0,ae,0,ae,0,ae,0,0,ae
ae,0,ae,0,0,0,0,0,0,ae
ae,ae,ae,0,0,0,0,0,0,ae
ae,ae,0,ae,0,0,0,0,0,ae
ae,ae,0,0,ae,0,0,0,0,ae
ae,ae,0,0,0,ae,0,0,0,ae
ae,0,ae,0,ae,0,0,0,0,ae
ae,0,ae,0,0,0,ae,0,0,ae
ae,ae,ae,ae,0,0,0,0,0,ae
ae,ae,ae,0,ae,0,0,0,0,ae
ae,ae,ae,0,0,ae,0,0,0,ae
ae,ae,ae,0,0,0,ae,0,0,ae
ae,ae,ae,0,0,0,0,ae,0,ae
ae,ae,ae,0,0,0,0,0,ae,ae
ae,ae,0,ae,0,ae,0,0,0,ae
ae,ae,0,ae,0,0,ae,0,0,ae
ae,0,ae,0,ae,0,ae,0,0,ae
#c15
0,af,af,af,0,0,0,0,0,af
0,af,af,0,af,0,0,0,0,af
0,af,af,0,0,af,0,0,0,af
0,af,af,0,0,0,af,0,0,af
0,af,af,0,0,0,0,af,0,af
0,af,af,0,0,0,0,0,af,af
0,af,0,af,0,af,0,0,0,af
0,af,0,af,0,0,af,0,0,af
0,af,0,0,af,0,af,0,0,af
0,0,af,0,af,0,af,0,0,af
0,af,af,0,0,af,0,af,0,af
0,0,af,0,af,0,af,0,af,af
0,af,af,af,af,0,0,af,0,af
0,af,af,af,0,af,af,af,0,af
af,af,af,0,0,0,0,0,0,af
af,af,0,af,0,0,0,0,0,af
af,af,0,0,af,0,0,0,0,af
af,af,0,0,0,af,0,0,0,af
af,0,af,0,af,0,0,0,0,af
af,0,af,0,0,0,af,0,0,af
af,af,af,af,0,0,0,0,0,af
af,af,af,0,af,0,0,0,0,af
af,af,af,0,0,0,af,0,0,af
af,af,af,0,0,0,0,af,0,af
af,af,af,0,0,0,0,0,af,af
af,af,0,af,0,af,0,0,0,af
af,af,0,af,0,0,af,0,0,af
af,af,0,0,af,0,af,0,0,af
af,0,af,0,af,0,af,0,0,af
af,af,af,0,af,af,0,0,0,af
af,af,af,0,0,af,0,0,af,af
#c17
0,ag,ag,ag,0,0,0,0,0,ag
0,ag,ag,0,ag,0,0,0,0,ag
0,ag,ag,0,0,ag,0,0,0,ag
0,ag,ag,0,0,0,ag,0,0,ag
0,ag,ag,0,0,0,0,ag,0,ag
0,ag,ag,0,0,0,0,0,ag,ag
0,ag,0,ag,0,ag,0,0,0,ag
0,ag,0,ag,0,0,ag,0,0,ag
0,ag,0,0,ag,0,ag,0,0,ag
0,0,ag,0,ag,0,ag,0,0,ag
0,ag,ag,0,ag,0,0,0,ag,ag
0,ag,ag,ag,ag,ag,ag,ag,0,ag
0,ag,ag,ag,ag,ag,ag,0,ag,ag
ag,ag,ag,0,0,0,0,0,0,ag
ag,ag,0,ag,0,0,0,0,0,ag
ag,ag,0,0,ag,0,0,0,0,ag
ag,ag,0,0,0,ag,0,0,0,ag
ag,0,ag,0,ag,0,0,0,0,ag
ag,0,ag,0,0,0,ag,0,0,ag
ag,ag,ag,ag,0,0,0,0,0,ag
ag,ag,ag,0,ag,0,0,0,0,ag
ag,ag,ag,0,0,ag,0,0,0,ag
ag,ag,ag,0,0,0,ag,0,0,ag
ag,ag,ag,0,0,0,0,ag,0,ag
ag,ag,ag,0,0,0,0,0,ag,ag
ag,ag,0,ag,0,ag,0,0,0,ag
ag,ag,0,ag,0,0,ag,0,0,ag
ag,ag,0,0,ag,0,ag,0,0,ag
ag,0,ag,0,ag,0,ag,0,0,ag
#c19
0,ah,0,ah,0,0,0,0,0,ah
0,ah,0,0,0,ah,0,0,0,ah
0,0,ah,0,0,0,ah,0,0,ah
0,ah,ah,ah,0,0,0,0,0,ah
0,ah,ah,0,0,0,0,0,ah,ah
0,0,ah,0,ah,0,ah,0,0,ah
0,ah,ah,ah,0,ah,0,0,0,ah
0,ah,ah,ah,0,0,ah,0,0,ah
0,ah,ah,0,0,ah,0,ah,0,ah
0,ah,ah,0,0,0,ah,ah,0,ah
0,ah,ah,ah,ah,0,0,0,ah,ah
0,ah,ah,0,ah,ah,ah,0,0,ah
ah,ah,ah,0,0,0,0,0,0,ah
ah,ah,0,ah,0,0,0,0,0,ah
ah,ah,0,0,ah,0,0,0,0,ah
ah,ah,0,0,0,ah,0,0,0,ah
ah,0,ah,0,ah,0,0,0,0,ah
ah,0,ah,0,0,0,ah,0,0,ah
ah,ah,ah,0,ah,0,0,0,0,ah
ah,ah,ah,0,0,ah,0,0,0,ah
ah,ah,ah,0,0,0,0,ah,0,ah
ah,ah,ah,0,0,0,0,0,ah,ah
ah,ah,0,ah,0,ah,0,0,0,ah
ah,ah,0,ah,0,0,ah,0,0,ah
ah,ah,0,0,ah,0,ah,0,0,ah
ah,0,ah,0,ah,0,ah,0,0,ah
ah,ah,ah,ah,ah,0,0,0,0,ah
ah,ah,ah,ah,0,ah,0,0,0,ah
ah,ah,ah,ah,0,0,ah,0,0,ah
ah,ah,ah,0,ah,ah,0,0,0,ah
ah,ah,ah,0,ah,0,ah,0,0,ah
ah,ah,ah,0,ah,0,0,ah,0,ah
ah,ah,ah,0,ah,0,0,0,ah,ah
ah,ah,ah,0,0,ah,ah,0,0,ah
ah,ah,ah,0,0,ah,0,ah,0,ah
ah,ah,ah,0,0,ah,0,0,ah,ah
ah,ah,ah,0,0,0,ah,ah,0,ah
ah,ah,0,ah,0,ah,0,ah,0,ah
ah,0,ah,0,ah,0,ah,0,ah,ah
#c21
0,ai,ai,ai,0,0,0,0,0,ai
0,ai,ai,0,ai,0,0,0,0,ai
0,ai,ai,0,0,ai,0,0,0,ai
0,ai,ai,0,0,0,ai,0,0,ai
0,ai,ai,0,0,0,0,ai,0,ai
0,ai,ai,0,0,0,0,0,ai,ai
0,ai,0,ai,0,ai,0,0,0,ai
0,ai,0,ai,0,0,ai,0,0,ai
0,ai,0,0,ai,0,ai,0,0,ai
0,0,ai,0,ai,0,ai,0,0,ai
0,ai,ai,ai,ai,ai,ai,0,0,ai
0,ai,ai,ai,ai,ai,0,ai,0,ai
0,ai,ai,ai,ai,0,ai,ai,0,ai
0,ai,ai,ai,ai,0,ai,0,ai,ai
0,ai,ai,ai,0,ai,ai,ai,0,ai
0,ai,ai,0,ai,ai,ai,0,ai,ai
ai,0,0,0,0,0,0,0,0,ai
ai,ai,0,0,0,0,0,0,0,ai
ai,0,ai,0,0,0,0,0,0,ai
ai,ai,ai,ai,0,0,0,0,0,ai
ai,ai,ai,0,ai,0,0,0,0,ai
ai,ai,ai,0,0,ai,0,0,0,ai
ai,ai,ai,0,0,0,ai,0,0,ai
ai,ai,ai,0,0,0,0,ai,0,ai
ai,ai,ai,0,0,0,0,0,ai,ai
ai,ai,0,ai,0,ai,0,0,0,ai
ai,ai,0,ai,0,0,ai,0,0,ai
ai,ai,0,0,ai,0,ai,0,0,ai
ai,0,ai,0,ai,0,ai,0,0,ai
ai,ai,ai,ai,ai,ai,0,0,0,ai
ai,ai,ai,ai,ai,0,ai,0,0,ai
ai,ai,ai,ai,ai,0,0,ai,0,ai
ai,ai,ai,ai,ai,0,0,0,ai,ai
ai,ai,ai,ai,0,ai,ai,0,0,ai
ai,ai,ai,ai,0,ai,0,ai,0,ai
ai,ai,ai,0,ai,ai,ai,0,0,ai
ai,ai,ai,0,ai,ai,0,ai,0,ai
ai,ai,ai,0,ai,0,ai,ai,0,ai
ai,ai,ai,0,ai,0,ai,0,ai,ai
#c23
0,aj,aj,aj,0,0,0,0,0,aj
0,aj,aj,0,aj,0,0,0,0,aj
0,aj,aj,0,0,aj,0,0,0,aj
0,aj,aj,0,0,0,aj,0,0,aj
0,aj,aj,0,0,0,0,aj,0,aj
0,aj,aj,0,0,0,0,0,aj,aj
0,aj,0,aj,0,aj,0,0,0,aj
0,aj,0,aj,0,0,aj,0,0,aj
0,aj,0,0,aj,0,aj,0,0,aj
0,0,aj,0,aj,0,aj,0,0,aj
aj,0,0,0,0,0,0,0,0,aj
aj,aj,0,0,0,0,0,0,0,aj
aj,0,aj,0,0,0,0,0,0,aj
aj,aj,aj,aj,aj,0,0,0,0,aj
aj,aj,aj,aj,0,aj,0,0,0,aj
aj,aj,aj,aj,0,0,aj,0,0,aj
aj,aj,aj,0,aj,aj,0,0,0,aj
aj,aj,aj,0,aj,0,aj,0,0,aj
aj,aj,aj,0,aj,0,0,aj,0,aj
aj,aj,aj,0,aj,0,0,0,aj,aj
aj,aj,aj,0,0,aj,aj,0,0,aj
aj,aj,aj,0,0,aj,0,aj,0,aj
aj,aj,aj,0,0,aj,0,0,aj,aj
aj,aj,aj,0,0,0,aj,aj,0,aj
aj,aj,0,aj,0,aj,0,aj,0,aj
aj,0,aj,0,aj,0,aj,0,aj,aj
aj,aj,aj,aj,aj,aj,0,0,0,aj
aj,aj,aj,aj,aj,0,aj,0,0,aj
aj,aj,aj,aj,aj,0,0,aj,0,aj
aj,aj,aj,aj,aj,0,0,0,aj,aj
aj,aj,aj,aj,0,aj,aj,0,0,aj
aj,aj,aj,aj,0,aj,0,aj,0,aj
aj,aj,aj,0,aj,aj,aj,0,0,aj
aj,aj,aj,0,aj,aj,0,aj,0,aj
aj,aj,aj,0,aj,0,aj,aj,0,aj
aj,aj,aj,0,aj,0,aj,0,aj,aj
aj,aj,aj,aj,aj,aj,aj,0,0,aj
aj,aj,aj,aj,aj,aj,0,aj,0,aj
aj,aj,aj,aj,aj,0,aj,aj,0,aj
aj,aj,aj,aj,aj,0,aj,0,aj,aj
aj,aj,aj,aj,0,aj,aj,aj,0,aj
aj,aj,aj,0,aj,aj,aj,0,aj,aj
aj,aj,aj,aj,aj,aj,aj,aj,0,aj
aj,aj,aj,aj,aj,aj,aj,0,aj,aj
aj,aj,aj,aj,aj,aj,aj,aj,aj,aj
#c25
0,ak,0,ak,0,0,0,0,0,ak
0,ak,ak,ak,0,0,0,0,0,ak
0,ak,ak,0,ak,0,0,0,0,ak
0,ak,ak,0,0,ak,0,0,0,ak
0,ak,ak,0,0,0,ak,0,0,ak
0,ak,ak,0,0,0,0,ak,0,ak
0,ak,ak,0,0,0,0,0,ak,ak
0,ak,0,ak,0,ak,0,0,0,ak
0,ak,0,ak,0,0,ak,0,0,ak
0,ak,0,0,ak,0,ak,0,0,ak
0,0,ak,0,ak,0,ak,0,0,ak
0,ak,ak,0,ak,ak,0,0,0,ak
0,0,ak,0,ak,0,ak,0,ak,ak
ak,ak,0,0,0,0,0,0,0,ak
ak,0,ak,0,0,0,0,0,0,ak
ak,0,ak,0,ak,0,0,0,0,ak
ak,0,ak,0,0,0,ak,0,0,ak
ak,ak,ak,ak,ak,0,0,0,0,ak
ak,ak,ak,ak,0,ak,0,0,0,ak
ak,ak,ak,ak,0,0,ak,0,0,ak
ak,ak,ak,0,ak,ak,0,0,0,ak
ak,ak,ak,0,ak,0,ak,0,0,ak
ak,ak,ak,0,ak,0,0,ak,0,ak
ak,ak,ak,0,ak,0,0,0,ak,ak
ak,ak,ak,0,0,ak,ak,0,0,ak
ak,ak,ak,0,0,ak,0,ak,0,ak
ak,ak,ak,0,0,ak,0,0,ak,ak
ak,ak,ak,0,0,0,ak,ak,0,ak
ak,ak,0,ak,0,ak,0,ak,0,ak
ak,0,ak,0,ak,0,ak,0,ak,ak
ak,ak,ak,ak,ak,ak,0,0,0,ak
ak,ak,ak,ak,ak,0,ak,0,0,ak
ak,ak,ak,ak,ak,0,0,ak,0,ak
ak,ak,ak,ak,ak,0,0,0,ak,ak
ak,ak,ak,ak,0,ak,ak,0,0,ak
ak,ak,ak,ak,0,ak,0,ak,0,ak
ak,ak,ak,0,ak,ak,ak,0,0,ak
ak,ak,ak,0,ak,ak,0,ak,0,ak
ak,ak,ak,0,ak,0,ak,ak,0,ak
ak,ak,ak,0,ak,0,ak,0,ak,ak
#c27
0,al,al,al,0,0,0,0,0,al
0,al,al,0,al,0,0,0,0,al
0,al,al,0,0,al,0,0,0,al
0,al,al,0,0,0,al,0,0,al
0,al,al,0,0,0,0,al,0,al
0,al,al,0,0,0,0,0,al,al
0,al,0,al,0,al,0,0,0,al
0,al,0,al,0,0,al,0,0,al
0,al,0,0,al,0,al,0,0,al
0,0,al,0,al,0,al,0,0,al
0,al,al,al,al,0,0,0,0,al
0,al,al,al,0,al,0,0,0,al
0,al,al,al,0,0,al,0,0,al
0,al,al,0,al,al,0,0,0,al
0,al,al,0,al,0,al,0,0,al
0,al,al,0,al,0,0,al,0,al
0,al,al,0,al,0,0,0,al,al
0,al,al,0,0,al,al,0,0,al
0,al,al,0,0,al,0,al,0,al
0,al,al,0,0,al,0,0,al,al
0,al,al,0,0,0,al,al,0,al
0,al,0,al,0,al,0,al,0,al
0,0,al,0,al,0,al,0,al,al
0,al,al,al,al,al,0,0,0,al
0,al,al,al,al,0,al,0,0,al
0,al,al,al,al,0,0,al,0,al
0,al,al,al,al,0,0,0,al,al
0,al,al,al,0,al,al,0,0,al
0,al,al,al,0,al,0,al,0,al
0,al,al,0,al,al,al,0,0,al
0,al,al,0,al,al,0,al,0,al
0,al,al,0,al,0,al,al,0,al
0,al,al,0,al,0,al,0,al,al
0,al,al,al,al,al,al,0,0,al
0,al,al,al,al,al,0,al,0,al
0,al,al,al,al,0,al,al,0,al
0,al,al,al,al,0,al,0,al,al
0,al,al,al,0,al,al,al,0,al
0,al,al,0,al,al,al,0,al,al
0,al,al,al,al,al,al,al,al,al
al,al,al,al,0,0,0,0,0,al
al,al,al,0,al,0,0,0,0,al
al,al,al,0,0,al,0,0,0,al
al,al,al,0,0,0,al,0,0,al
al,al,al,0,0,0,0,al,0,al
al,al,al,0,0,0,0,0,al,al
al,al,0,al,0,al,0,0,0,al
al,al,0,al,0,0,al,0,0,al
al,al,0,0,al,0,al,0,0,al
al,0,al,0,al,0,al,0,0,al
al,al,al,al,al,al,al,0,0,al
al,al,al,al,al,al,0,al,0,al
al,al,al,al,al,0,al,al,0,al
al,al,al,al,al,0,al,0,al,al
al,al,al,al,0,al,al,al,0,al
al,al,al,0,al,al,al,0,al,al
al,al,al,al,al,al,al,al,0,al
al,al,al,al,al,al,al,0,al,al
al,al,al,al,al,al,al,al,al,al
#c29
0,am,am,am,0,0,0,0,0,am
0,am,am,0,am,0,0,0,0,am
0,am,am,0,0,am,0,0,0,am
0,am,am,0,0,0,am,0,0,am
0,am,am,0,0,0,0,am,0,am
0,am,am,0,0,0,0,0,am,am
0,am,0,am,0,am,0,0,0,am
0,am,0,am,0,0,am,0,0,am
0,am,0,0,am,0,am,0,0,am
0,0,am,0,am,0,am,0,0,am
0,am,am,am,am,0,0,0,0,am
0,am,am,am,0,am,0,0,0,am
0,am,am,am,0,0,am,0,0,am
0,am,am,0,am,am,0,0,0,am
0,am,am,0,am,0,am,0,0,am
0,am,am,0,am,0,0,am,0,am
0,am,am,0,am,0,0,0,am,am
0,am,am,0,0,am,am,0,0,am
0,am,am,0,0,am,0,am,0,am
0,am,am,0,0,am,0,0,am,am
0,am,am,0,0,0,am,am,0,am
0,am,0,am,0,am,0,am,0,am
0,0,am,0,am,0,am,0,am,am
0,am,am,am,am,am,0,0,0,am
0,am,am,am,am,0,am,0,0,am
0,am,am,am,am,0,0,am,0,am
0,am,am,am,am,0,0,0,am,am
0,am,am,am,0,am,am,0,0,am
0,am,am,am,0,am,0,am,0,am
0,am,am,0,am,am,am,0,0,am
0,am,am,0,am,am,0,am,0,am
0,am,am,0,am,0,am,am,0,am
0,am,am,0,am,0,am,0,am,am
am,0,0,0,0,0,0,0,0,am
am,am,am,am,am,0,0,0,0,am
am,am,am,am,0,am,0,0,0,am
am,am,am,am,0,0,am,0,0,am
am,am,am,0,am,am,0,0,0,am
am,am,am,0,am,0,am,0,0,am
am,am,am,0,am,0,0,am,0,am
am,am,am,0,am,0,0,0,am,am
am,am,am,0,0,am,am,0,0,am
am,am,am,0,0,am,0,am,0,am
am,am,am,0,0,am,0,0,am,am
am,am,am,0,0,0,am,am,0,am
am,am,0,am,0,am,0,am,0,am
am,0,am,0,am,0,am,0,am,am
am,am,am,am,am,am,am,am,0,am
am,am,am,am,am,am,am,0,am,am
am,am,am,am,am,am,am,am,am,am
#c31
0,an,an,an,0,0,0,0,0,an
0,an,an,0,an,0,0,0,0,an
0,an,an,0,0,an,0,0,0,an
0,an,an,0,0,0,an,0,0,an
0,an,an,0,0,0,0,an,0,an
0,an,an,0,0,0,0,0,an,an
0,an,0,an,0,an,0,0,0,an
0,an,0,an,0,0,an,0,0,an
0,an,0,0,an,0,an,0,0,an
0,0,an,0,an,0,an,0,0,an
0,an,an,an,an,0,0,0,0,an
0,an,an,an,0,an,0,0,0,an
0,an,an,an,0,0,an,0,0,an
0,an,an,0,an,an,0,0,0,an
0,an,an,0,an,0,an,0,0,an
0,an,an,0,an,0,0,an,0,an
0,an,an,0,an,0,0,0,an,an
0,an,an,0,0,an,an,0,0,an
0,an,an,0,0,an,0,an,0,an
0,an,an,0,0,an,0,0,an,an
0,an,an,0,0,0,an,an,0,an
0,an,0,an,0,an,0,an,0,an
0,0,an,0,an,0,an,0,an,an
0,an,an,an,an,an,an,0,0,an
0,an,an,an,an,an,0,an,0,an
0,an,an,an,an,0,an,an,0,an
0,an,an,an,an,0,an,0,an,an
0,an,an,an,0,an,an,an,0,an
0,an,an,0,an,an,an,0,an,an
0,an,an,an,an,an,an,an,0,an
0,an,an,an,an,an,an,0,an,an
0,an,an,an,an,an,an,an,an,an
an,0,0,0,0,0,0,0,0,an
an,an,an,0,0,0,0,0,0,an
an,an,0,an,0,0,0,0,0,an
an,an,0,0,an,0,0,0,0,an
an,an,0,0,0,an,0,0,0,an
an,0,an,0,an,0,0,0,0,an
an,0,an,0,0,0,an,0,0,an
an,an,an,an,an,an,an,0,0,an
an,an,an,an,an,an,0,an,0,an
an,an,an,an,an,0,an,an,0,an
an,an,an,an,an,0,an,0,an,an
an,an,an,an,0,an,an,an,0,an
an,an,an,0,an,an,an,0,an,an
#c33
0,ao,ao,ao,0,0,0,0,0,ao
0,ao,ao,0,ao,0,0,0,0,ao
0,ao,ao,0,0,ao,0,0,0,ao
0,ao,ao,0,0,0,ao,0,0,ao
0,ao,ao,0,0,0,0,ao,0,ao
0,ao,ao,0,0,0,0,0,ao,ao
0,ao,0,ao,0,ao,0,0,0,ao
0,ao,0,ao,0,0,ao,0,0,ao
0,ao,0,0,ao,0,ao,0,0,ao
0,0,ao,0,ao,0,ao,0,0,ao
0,ao,ao,ao,ao,ao,ao,ao,0,ao
0,ao,ao,ao,ao,ao,ao,0,ao,ao
ao,0,0,0,0,0,0,0,0,ao
ao,ao,ao,0,0,0,0,0,0,ao
ao,ao,0,ao,0,0,0,0,0,ao
ao,ao,0,0,ao,0,0,0,0,ao
ao,ao,0,0,0,ao,0,0,0,ao
ao,0,ao,0,ao,0,0,0,0,ao
ao,0,ao,0,0,0,ao,0,0,ao
ao,ao,ao,ao,ao,0,0,0,0,ao
ao,ao,ao,ao,0,ao,0,0,0,ao
ao,ao,ao,ao,0,0,ao,0,0,ao
ao,ao,ao,0,ao,ao,0,0,0,ao
ao,ao,ao,0,ao,0,ao,0,0,ao
ao,ao,ao,0,ao,0,0,ao,0,ao
ao,ao,ao,0,ao,0,0,0,ao,ao
ao,ao,ao,0,0,ao,ao,0,0,ao
ao,ao,ao,0,0,ao,0,ao,0,ao
ao,ao,ao,0,0,ao,0,0,ao,ao
ao,ao,ao,0,0,0,ao,ao,0,ao
ao,ao,0,ao,0,ao,0,ao,0,ao
ao,0,ao,0,ao,0,ao,0,ao,ao
ao,ao,ao,ao,ao,ao,0,0,0,ao
ao,ao,ao,ao,ao,0,ao,0,0,ao
ao,ao,ao,ao,ao,0,0,ao,0,ao
ao,ao,ao,ao,ao,0,0,0,ao,ao
ao,ao,ao,ao,0,ao,ao,0,0,ao
ao,ao,ao,ao,0,ao,0,ao,0,ao
ao,ao,ao,0,ao,ao,ao,0,0,ao
ao,ao,ao,0,ao,ao,0,ao,0,ao
ao,ao,ao,0,ao,0,ao,ao,0,ao
ao,ao,ao,0,ao,0,ao,0,ao,ao
ao,ao,ao,ao,ao,ao,ao,ao,0,ao
ao,ao,ao,ao,ao,ao,ao,0,ao,ao
ao,ao,ao,ao,ao,ao,ao,ao,ao,ao
#c35
0,ap,ap,ap,0,0,0,0,0,ap
0,ap,ap,0,ap,0,0,0,0,ap
0,ap,ap,0,0,ap,0,0,0,ap
0,ap,ap,0,0,0,ap,0,0,ap
0,ap,ap,0,0,0,0,ap,0,ap
0,ap,ap,0,0,0,0,0,ap,ap
0,ap,0,ap,0,ap,0,0,0,ap
0,ap,0,ap,0,0,ap,0,0,ap
0,ap,0,0,ap,0,ap,0,0,ap
0,0,ap,0,ap,0,ap,0,0,ap
0,ap,ap,ap,ap,ap,ap,0,0,ap
0,ap,ap,ap,ap,ap,0,ap,0,ap
0,ap,ap,ap,ap,0,ap,ap,0,ap
0,ap,ap,ap,ap,0,ap,0,ap,ap
0,ap,ap,ap,0,ap,ap,ap,0,ap
0,ap,ap,0,ap,ap,ap,0,ap,ap
ap,ap,ap,0,0,0,0,0,0,ap
ap,ap,0,ap,0,0,0,0,0,ap
ap,ap,0,0,ap,0,0,0,0,ap
ap,ap,0,0,0,ap,0,0,0,ap
ap,0,ap,0,ap,0,0,0,0,ap
ap,0,ap,0,0,0,ap,0,0,ap
ap,ap,ap,ap,0,0,0,0,0,ap
ap,ap,ap,0,ap,0,0,0,0,ap
ap,ap,ap,0,0,ap,0,0,0,ap
ap,ap,ap,0,0,0,ap,0,0,ap
ap,ap,ap,0,0,0,0,ap,0,ap
ap,ap,ap,0,0,0,0,0,ap,ap
ap,ap,0,ap,0,ap,0,0,0,ap
ap,ap,0,ap,0,0,ap,0,0,ap
ap,ap,0,0,ap,0,ap,0,0,ap
ap,0,ap,0,ap,0,ap,0,0,ap
ap,ap,ap,ap,ap,ap,ap,ap,0,ap
ap,ap,ap,ap,ap,ap,ap,0,ap,ap
#c37
0,aq,aq,aq,0,0,0,0,0,aq
0,aq,aq,0,aq,0,0,0,0,aq
0,aq,aq,0,0,aq,0,0,0,aq
0,aq,aq,0,0,0,aq,0,0,aq
0,aq,aq,0,0,0,0,aq,0,aq
0,aq,aq,0,0,0,0,0,aq,aq
0,aq,0,aq,0,aq,0,0,0,aq
0,aq,0,aq,0,0,aq,0,0,aq
0,aq,0,0,aq,0,aq,0,0,aq
0,0,aq,0,aq,0,aq,0,0,aq
0,aq,aq,aq,aq,0,0,0,0,aq
0,aq,aq,aq,0,aq,0,0,0,aq
0,aq,aq,aq,0,0,aq,0,0,aq
0,aq,aq,0,aq,aq,0,0,0,aq
0,aq,aq,0,aq,0,aq,0,0,aq
0,aq,aq,0,aq,0,0,aq,0,aq
0,aq,aq,0,aq,0,0,0,aq,aq
0,aq,aq,0,0,aq,aq,0,0,aq
0,aq,aq,0,0,aq,0,aq,0,aq
0,aq,aq,0,0,aq,0,0,aq,aq
0,aq,aq,0,0,0,aq,aq,0,aq
0,aq,0,aq,0,aq,0,aq,0,aq
0,0,aq,0,aq,0,aq,0,aq,aq
0,aq,aq,aq,aq,aq,aq,0,0,aq
0,aq,aq,aq,aq,aq,0,aq,0,aq
0,aq,aq,aq,aq,0,aq,aq,0,aq
0,aq,aq,aq,aq,0,aq,0,aq,aq
0,aq,aq,aq,0,aq,aq,aq,0,aq
0,aq,aq,0,aq,aq,aq,0,aq,aq
aq,aq,aq,aq,0,0,0,0,0,aq
aq,aq,aq,0,aq,0,0,0,0,aq
aq,aq,aq,0,0,aq,0,0,0,aq
aq,aq,aq,0,0,0,aq,0,0,aq
aq,aq,aq,0,0,0,0,aq,0,aq
aq,aq,aq,0,0,0,0,0,aq,aq
aq,aq,0,aq,0,aq,0,0,0,aq
aq,aq,0,aq,0,0,aq,0,0,aq
aq,aq,0,0,aq,0,aq,0,0,aq
aq,0,aq,0,aq,0,aq,0,0,aq
aq,aq,aq,aq,aq,aq,0,0,0,aq
aq,aq,aq,aq,aq,0,aq,0,0,aq
aq,aq,aq,aq,aq,0,0,aq,0,aq
aq,aq,aq,aq,aq,0,0,0,aq,aq
aq,aq,aq,aq,0,aq,aq,0,0,aq
aq,aq,aq,aq,0,aq,0,aq,0,aq
aq,aq,aq,0,aq,aq,aq,0,0,aq
aq,aq,aq,0,aq,aq,0,aq,0,aq
aq,aq,aq,0,aq,0,aq,aq,0,aq
aq,aq,aq,0,aq,0,aq,0,aq,aq
aq,aq,aq,aq,aq,aq,aq,0,0,aq
aq,aq,aq,aq,aq,aq,0,aq,0,aq
aq,aq,aq,aq,aq,0,aq,aq,0,aq
aq,aq,aq,aq,aq,0,aq,0,aq,aq
aq,aq,aq,aq,0,aq,aq,aq,0,aq
aq,aq,aq,0,aq,aq,aq,0,aq,aq
#c39
0,ar,ar,ar,0,0,0,0,0,ar
0,ar,ar,0,ar,0,0,0,0,ar
0,ar,ar,0,0,ar,0,0,0,ar
0,ar,ar,0,0,0,ar,0,0,ar
0,ar,ar,0,0,0,0,ar,0,ar
0,ar,ar,0,0,0,0,0,ar,ar
0,ar,0,ar,0,ar,0,0,0,ar
0,ar,0,ar,0,0,ar,0,0,ar
0,ar,0,0,ar,0,ar,0,0,ar
0,0,ar,0,ar,0,ar,0,0,ar
0,ar,ar,ar,ar,ar,ar,ar,0,ar
0,ar,ar,ar,ar,ar,ar,0,ar,ar
0,ar,ar,ar,ar,ar,ar,ar,ar,ar
ar,ar,ar,0,0,0,0,0,0,ar
ar,ar,0,ar,0,0,0,0,0,ar
ar,ar,0,0,ar,0,0,0,0,ar
ar,ar,0,0,0,ar,0,0,0,ar
ar,0,ar,0,ar,0,0,0,0,ar
ar,0,ar,0,0,0,ar,0,0,ar
ar,ar,ar,ar,ar,0,0,0,0,ar
ar,ar,ar,ar,0,ar,0,0,0,ar
ar,ar,ar,ar,0,0,ar,0,0,ar
ar,ar,ar,0,ar,ar,0,0,0,ar
ar,ar,ar,0,ar,0,ar,0,0,ar
ar,ar,ar,0,ar,0,0,ar,0,ar
ar,ar,ar,0,ar,0,0,0,ar,ar
ar,ar,ar,0,0,ar,ar,0,0,ar
ar,ar,ar,0,0,ar,0,ar,0,ar
ar,ar,ar,0,0,ar,0,0,ar,ar
ar,ar,ar,0,0,0,ar,ar,0,ar
ar,ar,0,ar,0,ar,0,ar,0,ar
ar,0,ar,0,ar,0,ar,0,ar,ar
ar,ar,ar,ar,ar,ar,0,0,0,ar
ar,ar,ar,ar,ar,0,ar,0,0,ar
ar,ar,ar,ar,ar,0,0,ar,0,ar
ar,ar,ar,ar,ar,0,0,0,ar,ar
ar,ar,ar,ar,0,ar,ar,0,0,ar
ar,ar,ar,ar,0,ar,0,ar,0,ar
ar,ar,ar,0,ar,ar,ar,0,0,ar
ar,ar,ar,0,ar,ar,0,ar,0,ar
ar,ar,ar,0,ar,0,ar,ar,0,ar
ar,ar,ar,0,ar,0,ar,0,ar,ar
ar,ar,ar,ar,ar,ar,ar,0,0,ar
ar,ar,ar,ar,ar,ar,0,ar,0,ar
ar,ar,ar,ar,ar,0,ar,ar,0,ar
ar,ar,ar,ar,ar,0,ar,0,ar,ar
ar,ar,ar,ar,0,ar,ar,ar,0,ar
ar,ar,ar,0,ar,ar,ar,0,ar,ar
ar,ar,ar,ar,ar,ar,ar,ar,ar,ar
#c41
0,as,as,as,0,0,0,0,0,as
0,as,as,0,as,0,0,0,0,as
0,as,as,0,0,as,0,0,0,as
0,as,as,0,0,0,as,0,0,as
0,as,as,0,0,0,0,as,0,as
0,as,as,0,0,0,0,0,as,as
0,as,0,as,0,as,0,0,0,as
0,as,0,as,0,0,as,0,0,as
0,as,0,0,as,0,as,0,0,as
0,0,as,0,as,0,as,0,0,as
0,as,as,as,as,0,0,0,0,as
0,as,as,as,0,as,0,0,0,as
0,as,as,as,0,0,as,0,0,as
0,as,as,0,as,as,0,0,0,as
0,as,as,0,as,0,as,0,0,as
0,as,as,0,as,0,0,as,0,as
0,as,as,0,as,0,0,0,as,as
0,as,as,0,0,as,as,0,0,as
0,as,as,0,0,as,0,as,0,as
0,as,as,0,0,as,0,0,as,as
0,as,as,0,0,0,as,as,0,as
0,as,0,as,0,as,0,as,0,as
0,0,as,0,as,0,as,0,as,as
0,as,as,as,as,as,as,0,0,as
0,as,as,as,as,as,0,as,0,as
0,as,as,as,as,0,as,as,0,as
0,as,as,as,as,0,as,0,as,as
0,as,as,as,0,as,as,as,0,as
0,as,as,0,as,as,as,0,as,as
0,as,as,as,as,as,as,as,0,as
0,as,as,as,as,as,as,0,as,as
0,as,as,as,as,as,as,as,as,as
as,0,0,0,0,0,0,0,0,as
as,as,as,0,0,0,0,0,0,as
as,as,0,as,0,0,0,0,0,as
as,as,0,0,as,0,0,0,0,as
as,as,0,0,0,as,0,0,0,as
as,0,as,0,as,0,0,0,0,as
as,0,as,0,0,0,as,0,0,as
as,as,as,as,as,as,as,0,0,as
as,as,as,as,as,as,0,as,0,as
as,as,as,as,as,0,as,as,0,as
as,as,as,as,as,0,as,0,as,as
as,as,as,as,0,as,as,as,0,as
as,as,as,0,as,as,as,0,as,as
as,as,as,as,as,as,as,as,0,as
as,as,as,as,as,as,as,0,as,as
as,as,as,as,as,as,as,as,as,as
#c43
0,at,at,at,0,0,0,0,0,at
0,at,at,0,at,0,0,0,0,at
0,at,at,0,0,at,0,0,0,at
0,at,at,0,0,0,at,0,0,at
0,at,at,0,0,0,0,at,0,at
0,at,at,0,0,0,0,0,at,at
0,at,0,at,0,at,0,0,0,at
0,at,0,at,0,0,at,0,0,at
0,at,0,0,at,0,at,0,0,at
0,0,at,0,at,0,at,0,0,at
0,at,at,at,at,0,0,0,0,at
0,at,at,at,0,at,0,0,0,at
0,at,at,at,0,0,at,0,0,at
0,at,at,0,at,at,0,0,0,at
0,at,at,0,at,0,at,0,0,at
0,at,at,0,at,0,0,at,0,at
0,at,at,0,at,0,0,0,at,at
0,at,at,0,0,at,at,0,0,at
0,at,at,0,0,at,0,at,0,at
0,at,at,0,0,at,0,0,at,at
0,at,at,0,0,0,at,at,0,at
0,at,0,at,0,at,0,at,0,at
0,0,at,0,at,0,at,0,at,at
0,at,at,at,at,at,0,0,0,at
0,at,at,at,at,0,at,0,0,at
0,at,at,at,at,0,0,at,0,at
0,at,at,at,at,0,0,0,at,at
0,at,at,at,0,at,at,0,0,at
0,at,at,at,0,at,0,at,0,at
0,at,at,0,at,at,at,0,0,at
0,at,at,0,at,at,0,at,0,at
0,at,at,0,at,0,at,at,0,at
0,at,at,0,at,0,at,0,at,at
0,at,at,at,at,at,at,0,0,at
0,at,at,at,at,at,0,at,0,at
0,at,at,at,at,0,at,at,0,at
0,at,at,at,at,0,at,0,at,at
0,at,at,at,0,at,at,at,0,at
0,at,at,0,at,at,at,0,at,at
0,at,at,at,at,at,at,at,0,at
0,at,at,at,at,at,at,0,at,at
0,at,at,at,at,at,at,at,at,at
at,0,0,0,0,0,0,0,0,at
at,at,at,at,at,0,0,0,0,at
at,at,at,at,0,at,0,0,0,at
at,at,at,at,0,0,at,0,0,at
at,at,at,0,at,at,0,0,0,at
at,at,at,0,at,0,at,0,0,at
at,at,at,0,at,0,0,at,0,at
at,at,at,0,at,0,0,0,at,at
at,at,at,0,0,at,at,0,0,at
at,at,at,0,0,at,0,at,0,at
at,at,at,0,0,at,0,0,at,at
at,at,at,0,0,0,at,at,0,at
at,at,0,at,0,at,0,at,0,at
at,0,at,0,at,0,at,0,at,at
at,at,at,at,at,at,0,0,0,at
at,at,at,at,at,0,at,0,0,at
at,at,at,at,at,0,0,at,0,at
at,at,at,at,at,0,0,0,at,at
at,at,at,at,0,at,at,0,0,at
at,at,at,at,0,at,0,at,0,at
at,at,at,0,at,at,at,0,0,at
at,at,at,0,at,at,0,at,0,at
at,at,at,0,at,0,at,at,0,at
at,at,at,0,at,0,at,0,at,at
#c45
0,au,au,au,0,0,0,0,0,au
0,au,au,0,au,0,0,0,0,au
0,au,au,0,0,au,0,0,0,au
0,au,au,0,0,0,au,0,0,au
0,au,au,0,0,0,0,au,0,au
0,au,au,0,0,0,0,0,au,au
0,au,0,au,0,au,0,0,0,au
0,au,0,au,0,0,au,0,0,au
0,au,0,0,au,0,au,0,0,au
0,0,au,0,au,0,au,0,0,au
0,au,au,au,au,au,au,au,0,au
0,au,au,au,au,au,au,0,au,au
au,au,au,0,0,0,0,0,0,au
au,au,0,au,0,0,0,0,0,au
au,au,0,0,au,0,0,0,0,au
au,au,0,0,0,au,0,0,0,au
au,0,au,0,au,0,0,0,0,au
au,0,au,0,0,0,au,0,0,au
au,au,au,au,0,0,0,0,0,au
au,au,au,0,au,0,0,0,0,au
au,au,au,0,0,au,0,0,0,au
au,au,au,0,0,0,au,0,0,au
au,au,au,0,0,0,0,au,0,au
au,au,au,0,0,0,0,0,au,au
au,au,0,au,0,au,0,0,0,au
au,au,0,au,0,0,au,0,0,au
au,au,0,0,au,0,au,0,0,au
au,0,au,0,au,0,au,0,0,au
au,au,au,au,au,au,au,0,0,au
au,au,au,au,au,au,0,au,0,au
au,au,au,au,au,0,au,au,0,au
au,au,au,au,au,0,au,0,au,au
au,au,au,au,0,au,au,au,0,au
au,au,au,0,au,au,au,0,au,au
au,au,au,au,au,au,au,au,0,au
au,au,au,au,au,au,au,0,au,au
#c47
0,av,av,av,0,0,0,0,0,av
0,av,av,0,av,0,0,0,0,av
0,av,av,0,0,av,0,0,0,av
0,av,av,0,0,0,av,0,0,av
0,av,av,0,0,0,0,av,0,av
0,av,av,0,0,0,0,0,av,av
0,av,0,av,0,av,0,0,0,av
0,av,0,av,0,0,av,0,0,av
0,av,0,0,av,0,av,0,0,av
0,0,av,0,av,0,av,0,0,av
0,av,av,av,av,0,0,0,0,av
0,av,av,av,0,av,0,0,0,av
0,av,av,av,0,0,av,0,0,av
0,av,av,0,av,av,0,0,0,av
0,av,av,0,av,0,av,0,0,av
0,av,av,0,av,0,0,av,0,av
0,av,av,0,av,0,0,0,av,av
0,av,av,0,0,av,av,0,0,av
0,av,av,0,0,av,0,av,0,av
0,av,av,0,0,av,0,0,av,av
0,av,av,0,0,0,av,av,0,av
0,av,0,av,0,av,0,av,0,av
0,0,av,0,av,0,av,0,av,av
0,av,av,av,av,av,av,av,0,av
0,av,av,av,av,av,av,0,av,av
av,0,0,0,0,0,0,0,0,av
av,av,0,0,0,0,0,0,0,av
av,0,av,0,0,0,0,0,0,av
av,av,av,av,av,0,0,0,0,av
av,av,av,av,0,av,0,0,0,av
av,av,av,av,0,0,av,0,0,av
av,av,av,0,av,av,0,0,0,av
av,av,av,0,av,0,av,0,0,av
av,av,av,0,av,0,0,av,0,av
av,av,av,0,av,0,0,0,av,av
av,av,av,0,0,av,av,0,0,av
av,av,av,0,0,av,0,av,0,av
av,av,av,0,0,av,0,0,av,av
av,av,av,0,0,0,av,av,0,av
av,av,0,av,0,av,0,av,0,av
av,0,av,0,av,0,av,0,av,av
av,av,av,av,av,av,0,0,0,av
av,av,av,av,av,0,av,0,0,av
av,av,av,av,av,0,0,av,0,av
av,av,av,av,av,0,0,0,av,av
av,av,av,av,0,av,av,0,0,av
av,av,av,av,0,av,0,av,0,av
av,av,av,0,av,av,av,0,0,av
av,av,av,0,av,av,0,av,0,av
av,av,av,0,av,0,av,av,0,av
av,av,av,0,av,0,av,0,av,av
av,av,av,av,av,av,av,av,0,av
av,av,av,av,av,av,av,0,av,av
av,av,av,av,av,av,av,av,av,av
#c49
0,aw,aw,aw,0,0,0,0,0,aw
0,aw,aw,0,aw,0,0,0,0,aw
0,aw,aw,0,0,aw,0,0,0,aw
0,aw,aw,0,0,0,aw,0,0,aw
0,aw,aw,0,0,0,0,aw,0,aw
0,aw,aw,0,0,0,0,0,aw,aw
0,aw,0,aw,0,aw,0,0,0,aw
0,aw,0,aw,0,0,aw,0,0,aw
0,aw,0,0,aw,0,aw,0,0,aw
0,0,aw,0,aw,0,aw,0,0,aw
0,aw,aw,aw,aw,0,0,0,0,aw
0,aw,aw,aw,0,aw,0,0,0,aw
0,aw,aw,aw,0,0,aw,0,0,aw
0,aw,aw,0,aw,aw,0,0,0,aw
0,aw,aw,0,aw,0,aw,0,0,aw
0,aw,aw,0,aw,0,0,aw,0,aw
0,aw,aw,0,aw,0,0,0,aw,aw
0,aw,aw,0,0,aw,aw,0,0,aw
0,aw,aw,0,0,aw,0,aw,0,aw
0,aw,aw,0,0,aw,0,0,aw,aw
0,aw,aw,0,0,0,aw,aw,0,aw
0,aw,0,aw,0,aw,0,aw,0,aw
0,0,aw,0,aw,0,aw,0,aw,aw
0,aw,aw,aw,aw,aw,0,0,0,aw
0,aw,aw,aw,aw,0,aw,0,0,aw
0,aw,aw,aw,aw,0,0,aw,0,aw
0,aw,aw,aw,aw,0,0,0,aw,aw
0,aw,aw,aw,0,aw,aw,0,0,aw
0,aw,aw,aw,0,aw,0,aw,0,aw
0,aw,aw,0,aw,aw,aw,0,0,aw
0,aw,aw,0,aw,aw,0,aw,0,aw
0,aw,aw,0,aw,0,aw,aw,0,aw
0,aw,aw,0,aw,0,aw,0,aw,aw
aw,0,0,0,0,0,0,0,0,aw
aw,aw,aw,aw,aw,0,0,0,0,aw
aw,aw,aw,aw,0,aw,0,0,0,aw
aw,aw,aw,aw,0,0,aw,0,0,aw
aw,aw,aw,0,aw,aw,0,0,0,aw
aw,aw,aw,0,aw,0,aw,0,0,aw
aw,aw,aw,0,aw,0,0,aw,0,aw
aw,aw,aw,0,aw,0,0,0,aw,aw
aw,aw,aw,0,0,aw,aw,0,0,aw
aw,aw,aw,0,0,aw,0,aw,0,aw
aw,aw,aw,0,0,aw,0,0,aw,aw
aw,aw,aw,0,0,0,aw,aw,0,aw
aw,aw,0,aw,0,aw,0,aw,0,aw
aw,0,aw,0,aw,0,aw,0,aw,aw
aw,aw,aw,aw,aw,aw,0,0,0,aw
aw,aw,aw,aw,aw,0,aw,0,0,aw
aw,aw,aw,aw,aw,0,0,aw,0,aw
aw,aw,aw,aw,aw,0,0,0,aw,aw
aw,aw,aw,aw,0,aw,aw,0,0,aw
aw,aw,aw,aw,0,aw,0,aw,0,aw
aw,aw,aw,0,aw,aw,aw,0,0,aw
aw,aw,aw,0,aw,aw,0,aw,0,aw
aw,aw,aw,0,aw,0,aw,aw,0,aw
aw,aw,aw,0,aw,0,aw,0,aw,aw
aw,aw,aw,aw,aw,aw,aw,aw,0,aw
aw,aw,aw,aw,aw,aw,aw,0,aw,aw
aw,aw,aw,aw,aw,aw,aw,aw,aw,aw
#c53
0,za,za,za,0,0,0,0,0,za
0,za,za,0,za,0,0,0,0,za
0,za,za,0,0,za,0,0,0,za
0,za,za,0,0,0,za,0,0,za
0,za,za,0,0,0,0,za,0,za
0,za,za,0,0,0,0,0,za,za
0,za,0,za,0,za,0,0,0,za
0,za,0,za,0,0,za,0,0,za
0,za,0,0,za,0,za,0,0,za
0,0,za,0,za,0,za,0,0,za
0,za,za,za,za,0,0,0,0,za
0,za,za,za,0,za,0,0,0,za
0,za,za,za,0,0,za,0,0,za
0,za,za,0,za,za,0,0,0,za
0,za,za,0,za,0,za,0,0,za
0,za,za,0,za,0,0,za,0,za
0,za,za,0,za,0,0,0,za,za
0,za,za,0,0,za,za,0,0,za
0,za,za,0,0,za,0,za,0,za
0,za,za,0,0,za,0,0,za,za
0,za,za,0,0,0,za,za,0,za
0,za,0,za,0,za,0,za,0,za
0,0,za,0,za,0,za,0,za,za
0,za,za,za,za,za,0,0,0,za
0,za,za,za,za,0,za,0,0,za
0,za,za,za,za,0,0,za,0,za
0,za,za,za,za,0,0,0,za,za
0,za,za,za,0,za,za,0,0,za
0,za,za,za,0,za,0,za,0,za
0,za,za,0,za,za,za,0,0,za
0,za,za,0,za,za,0,za,0,za
0,za,za,0,za,0,za,za,0,za
0,za,za,0,za,0,za,0,za,za
za,za,za,za,za,0,0,0,0,za
za,za,za,za,0,za,0,0,0,za
za,za,za,za,0,0,za,0,0,za
za,za,za,0,za,za,0,0,0,za
za,za,za,0,za,0,za,0,0,za
za,za,za,0,za,0,0,za,0,za
za,za,za,0,za,0,0,0,za,za
za,za,za,0,0,za,za,0,0,za
za,za,za,0,0,za,0,za,0,za
za,za,za,0,0,za,0,0,za,za
za,za,za,0,0,0,za,za,0,za
za,za,0,za,0,za,0,za,0,za
za,0,za,0,za,0,za,0,za,za
za,za,za,za,za,za,0,0,0,za
za,za,za,za,za,0,za,0,0,za
za,za,za,za,za,0,0,za,0,za
za,za,za,za,za,0,0,0,za,za
za,za,za,za,0,za,za,0,0,za
za,za,za,za,0,za,0,za,0,za
za,za,za,0,za,za,za,0,0,za
za,za,za,0,za,za,0,za,0,za
za,za,za,0,za,0,za,za,0,za
za,za,za,0,za,0,za,0,za,za
za,za,za,za,za,za,za,za,0,za
za,za,za,za,za,za,za,0,za,za
#c55
0,zb,zb,zb,0,0,0,0,0,zb
0,zb,zb,0,zb,0,0,0,0,zb
0,zb,zb,0,0,zb,0,0,0,zb
0,zb,zb,0,0,0,zb,0,0,zb
0,zb,zb,0,0,0,0,zb,0,zb
0,zb,zb,0,0,0,0,0,zb,zb
0,zb,0,zb,0,zb,0,0,0,zb
0,zb,0,zb,0,0,zb,0,0,zb
0,zb,0,0,zb,0,zb,0,0,zb
0,0,zb,0,zb,0,zb,0,0,zb
0,zb,zb,zb,zb,0,0,0,0,zb
0,zb,zb,zb,0,zb,0,0,0,zb
0,zb,zb,zb,0,0,zb,0,0,zb
0,zb,zb,0,zb,zb,0,0,0,zb
0,zb,zb,0,zb,0,zb,0,0,zb
0,zb,zb,0,zb,0,0,zb,0,zb
0,zb,zb,0,zb,0,0,0,zb,zb
0,zb,zb,0,0,zb,zb,0,0,zb
0,zb,zb,0,0,zb,0,zb,0,zb
0,zb,zb,0,0,zb,0,0,zb,zb
0,zb,zb,0,0,0,zb,zb,0,zb
0,zb,0,zb,0,zb,0,zb,0,zb
0,0,zb,0,zb,0,zb,0,zb,zb
0,zb,zb,zb,zb,zb,0,0,0,zb
0,zb,zb,zb,zb,0,zb,0,0,zb
0,zb,zb,zb,zb,0,0,zb,0,zb
0,zb,zb,zb,zb,0,0,0,zb,zb
0,zb,zb,zb,0,zb,zb,0,0,zb
0,zb,zb,zb,0,zb,0,zb,0,zb
0,zb,zb,0,zb,zb,zb,0,0,zb
0,zb,zb,0,zb,zb,0,zb,0,zb
0,zb,zb,0,zb,0,zb,zb,0,zb
0,zb,zb,0,zb,0,zb,0,zb,zb
0,zb,zb,zb,zb,zb,zb,zb,0,zb
0,zb,zb,zb,zb,zb,zb,0,zb,zb
zb,zb,0,0,0,0,0,0,0,zb
zb,0,zb,0,0,0,0,0,0,zb
zb,zb,zb,zb,zb,zb,0,0,0,zb
zb,zb,zb,zb,zb,0,zb,0,0,zb
zb,zb,zb,zb,zb,0,0,zb,0,zb
zb,zb,zb,zb,zb,0,0,0,zb,zb
zb,zb,zb,zb,0,zb,zb,0,0,zb
zb,zb,zb,zb,0,zb,0,zb,0,zb
zb,zb,zb,0,zb,zb,zb,0,0,zb
zb,zb,zb,0,zb,zb,0,zb,0,zb
zb,zb,zb,0,zb,0,zb,zb,0,zb
zb,zb,zb,0,zb,0,zb,0,zb,zb
zb,zb,zb,zb,zb,zb,zb,zb,zb,zb
#c59
0,zd,zd,zd,0,0,0,0,0,zd
0,zd,zd,0,zd,0,0,0,0,zd
0,zd,zd,0,0,zd,0,0,0,zd
0,zd,zd,0,0,0,zd,0,0,zd
0,zd,zd,0,0,0,0,zd,0,zd
0,zd,zd,0,0,0,0,0,zd,zd
0,zd,0,zd,0,zd,0,0,0,zd
0,zd,0,zd,0,0,zd,0,0,zd
0,zd,0,0,zd,0,zd,0,0,zd
0,0,zd,0,zd,0,zd,0,0,zd
0,zd,zd,zd,zd,zd,zd,0,0,zd
0,zd,zd,zd,zd,zd,0,zd,0,zd
0,zd,zd,zd,zd,0,zd,zd,0,zd
0,zd,zd,zd,zd,0,zd,0,zd,zd
0,zd,zd,zd,0,zd,zd,zd,0,zd
0,zd,zd,0,zd,zd,zd,0,zd,zd
0,zd,zd,zd,zd,zd,zd,zd,0,zd
0,zd,zd,zd,zd,zd,zd,0,zd,zd
zd,0,0,0,0,0,0,0,0,zd
zd,zd,zd,zd,0,0,0,0,0,zd
zd,zd,zd,0,zd,0,0,0,0,zd
zd,zd,zd,0,0,zd,0,0,0,zd
zd,zd,zd,0,0,0,zd,0,0,zd
zd,zd,zd,0,0,0,0,zd,0,zd
zd,zd,zd,0,0,0,0,0,zd,zd
zd,zd,0,zd,0,zd,0,0,0,zd
zd,zd,0,zd,0,0,zd,0,0,zd
zd,zd,0,0,zd,0,zd,0,0,zd
zd,0,zd,0,zd,0,zd,0,0,zd
zd,zd,zd,zd,zd,zd,0,0,0,zd
zd,zd,zd,zd,zd,0,zd,0,0,zd
zd,zd,zd,zd,zd,0,0,zd,0,zd
zd,zd,zd,zd,zd,0,0,0,zd,zd
zd,zd,zd,zd,0,zd,zd,0,0,zd
zd,zd,zd,zd,0,zd,0,zd,0,zd
zd,zd,zd,0,zd,zd,zd,0,0,zd
zd,zd,zd,0,zd,zd,0,zd,0,zd
zd,zd,zd,0,zd,0,zd,zd,0,zd
zd,zd,zd,0,zd,0,zd,0,zd,zd
zd,zd,zd,zd,zd,zd,zd,0,0,zd
zd,zd,zd,zd,zd,zd,0,zd,0,zd
zd,zd,zd,zd,zd,0,zd,zd,0,zd
zd,zd,zd,zd,zd,0,zd,0,zd,zd
zd,zd,zd,zd,0,zd,zd,zd,0,zd
zd,zd,zd,0,zd,zd,zd,0,zd,zd
zd,zd,zd,zd,zd,zd,zd,zd,0,zd
zd,zd,zd,zd,zd,zd,zd,0,zd,zd
zd,zd,zd,zd,zd,zd,zd,zd,zd,zd
#c63
0,zf,zf,zf,0,0,0,0,0,zf
0,zf,zf,0,zf,0,0,0,0,zf
0,zf,zf,0,0,zf,0,0,0,zf
0,zf,zf,0,0,0,zf,0,0,zf
0,zf,zf,0,0,0,0,zf,0,zf
0,zf,zf,0,0,0,0,0,zf,zf
0,zf,0,zf,0,zf,0,0,0,zf
0,zf,0,zf,0,0,zf,0,0,zf
0,zf,0,0,zf,0,zf,0,0,zf
0,0,zf,0,zf,0,zf,0,0,zf
0,zf,zf,zf,zf,0,0,0,0,zf
0,zf,zf,zf,0,zf,0,0,0,zf
0,zf,zf,zf,0,0,zf,0,0,zf
0,zf,zf,0,zf,zf,0,0,0,zf
0,zf,zf,0,zf,0,zf,0,0,zf
0,zf,zf,0,zf,0,0,zf,0,zf
0,zf,zf,0,zf,0,0,0,zf,zf
0,zf,zf,0,0,zf,zf,0,0,zf
0,zf,zf,0,0,zf,0,zf,0,zf
0,zf,zf,0,0,zf,0,0,zf,zf
0,zf,zf,0,0,0,zf,zf,0,zf
0,zf,0,zf,0,zf,0,zf,0,zf
0,0,zf,0,zf,0,zf,0,zf,zf
0,zf,zf,zf,zf,zf,zf,zf,zf,zf
zf,0,0,0,0,0,0,0,0,zf
zf,zf,zf,zf,zf,zf,0,0,0,zf
zf,zf,zf,zf,zf,0,zf,0,0,zf
zf,zf,zf,zf,zf,0,0,zf,0,zf
zf,zf,zf,zf,zf,0,0,0,zf,zf
zf,zf,zf,zf,0,zf,zf,0,0,zf
zf,zf,zf,zf,0,zf,0,zf,0,zf
zf,zf,zf,0,zf,zf,zf,0,0,zf
zf,zf,zf,0,zf,zf,0,zf,0,zf
zf,zf,zf,0,zf,0,zf,zf,0,zf
zf,zf,zf,0,zf,0,zf,0,zf,zf
zf,zf,zf,zf,zf,zf,zf,0,0,zf
zf,zf,zf,zf,zf,zf,0,zf,0,zf
zf,zf,zf,zf,zf,0,zf,zf,0,zf
zf,zf,zf,zf,zf,0,zf,0,zf,zf
zf,zf,zf,zf,0,zf,zf,zf,0,zf
zf,zf,zf,0,zf,zf,zf,0,zf,zf
zf,zf,zf,zf,zf,zf,zf,zf,0,zf
zf,zf,zf,zf,zf,zf,zf,0,zf,zf
zf,zf,zf,zf,zf,zf,zf,zf,zf,zf
#c67
0,zi,zi,zi,0,0,0,0,0,zi
0,zi,zi,0,zi,0,0,0,0,zi
0,zi,zi,0,0,zi,0,0,0,zi
0,zi,zi,0,0,0,zi,0,0,zi
0,zi,zi,0,0,0,0,zi,0,zi
0,zi,zi,0,0,0,0,0,zi,zi
0,zi,0,zi,0,zi,0,0,0,zi
0,zi,0,zi,0,0,zi,0,0,zi
0,zi,0,0,zi,0,zi,0,0,zi
0,0,zi,0,zi,0,zi,0,0,zi
0,zi,zi,zi,zi,0,0,0,0,zi
0,zi,zi,zi,0,zi,0,0,0,zi
0,zi,zi,zi,0,0,zi,0,0,zi
0,zi,zi,0,zi,zi,0,0,0,zi
0,zi,zi,0,zi,0,zi,0,0,zi
0,zi,zi,0,zi,0,0,zi,0,zi
0,zi,zi,0,zi,0,0,0,zi,zi
0,zi,zi,0,0,zi,zi,0,0,zi
0,zi,zi,0,0,zi,0,zi,0,zi
0,zi,zi,0,0,zi,0,0,zi,zi
0,zi,zi,0,0,0,zi,zi,0,zi
0,zi,0,zi,0,zi,0,zi,0,zi
0,0,zi,0,zi,0,zi,0,zi,zi
0,zi,zi,zi,zi,zi,zi,zi,zi,zi
zi,0,0,0,0,0,0,0,0,zi
zi,zi,zi,0,0,0,0,0,0,zi
zi,zi,0,zi,0,0,0,0,0,zi
zi,zi,0,0,zi,0,0,0,0,zi
zi,zi,0,0,0,zi,0,0,0,zi
zi,0,zi,0,zi,0,0,0,0,zi
zi,0,zi,0,0,0,zi,0,0,zi
zi,zi,zi,zi,zi,zi,0,0,0,zi
zi,zi,zi,zi,zi,0,zi,0,0,zi
zi,zi,zi,zi,zi,0,0,zi,0,zi
zi,zi,zi,zi,zi,0,0,0,zi,zi
zi,zi,zi,zi,0,zi,zi,0,0,zi
zi,zi,zi,zi,0,zi,0,zi,0,zi
zi,zi,zi,0,zi,zi,zi,0,0,zi
zi,zi,zi,0,zi,zi,0,zi,0,zi
zi,zi,zi,0,zi,0,zi,zi,0,zi
zi,zi,zi,0,zi,0,zi,0,zi,zi
zi,zi,zi,zi,zi,zi,zi,0,0,zi
zi,zi,zi,zi,zi,zi,0,zi,0,zi
zi,zi,zi,zi,zi,0,zi,zi,0,zi
zi,zi,zi,zi,zi,0,zi,0,zi,zi
zi,zi,zi,zi,0,zi,zi,zi,0,zi
zi,zi,zi,0,zi,zi,zi,0,zi,zi
#c73
0,zk,0,0,0,zk,0,0,0,zk
0,zk,zk,zk,0,0,0,0,0,zk
0,zk,zk,0,zk,0,0,0,0,zk
0,zk,zk,0,0,zk,0,0,0,zk
0,zk,zk,0,0,0,zk,0,0,zk
0,zk,zk,0,0,0,0,zk,0,zk
0,zk,zk,0,0,0,0,0,zk,zk
0,zk,0,zk,0,zk,0,0,0,zk
0,zk,0,zk,0,0,zk,0,0,zk
0,zk,0,0,zk,0,zk,0,0,zk
0,0,zk,0,zk,0,zk,0,0,zk
0,zk,zk,0,zk,zk,0,0,0,zk
0,zk,zk,0,zk,0,0,zk,0,zk
0,0,zk,0,zk,0,zk,0,zk,zk
0,zk,zk,zk,zk,zk,zk,zk,0,zk
0,zk,zk,zk,zk,zk,zk,0,zk,zk
zk,zk,zk,0,0,0,0,0,0,zk
zk,zk,0,zk,0,0,0,0,0,zk
zk,zk,0,0,zk,0,0,0,0,zk
zk,zk,0,0,0,zk,0,0,0,zk
zk,0,zk,0,zk,0,0,0,0,zk
zk,0,zk,0,0,0,zk,0,0,zk
zk,zk,zk,0,zk,0,0,0,0,zk
zk,zk,zk,0,0,zk,0,0,0,zk
zk,zk,zk,0,0,0,zk,0,0,zk
zk,zk,zk,0,0,0,0,zk,0,zk
zk,zk,zk,0,0,0,0,0,zk,zk
zk,zk,0,zk,0,zk,0,0,0,zk
zk,zk,0,zk,0,0,zk,0,0,zk
zk,zk,0,0,zk,0,zk,0,0,zk
zk,0,zk,0,zk,0,zk,0,0,zk
zk,zk,zk,0,zk,zk,0,0,0,zk
zk,zk,zk,0,zk,0,0,zk,0,zk
zk,zk,zk,0,zk,0,0,0,zk,zk
zk,0,zk,0,zk,0,zk,0,zk,zk
zk,zk,zk,zk,zk,zk,zk,zk,0,zk
zk,zk,zk,zk,zk,zk,zk,0,zk,zk
#c81
0,zl,zl,zl,0,0,0,0,0,zl
0,zl,zl,0,zl,0,0,0,0,zl
0,zl,zl,0,0,zl,0,0,0,zl
0,zl,zl,0,0,0,zl,0,0,zl
0,zl,zl,0,0,0,0,zl,0,zl
0,zl,zl,0,0,0,0,0,zl,zl
0,zl,0,zl,0,zl,0,0,0,zl
0,zl,0,zl,0,0,zl,0,0,zl
0,zl,0,0,zl,0,zl,0,0,zl
0,0,zl,0,zl,0,zl,0,0,zl
0,zl,zl,zl,zl,0,0,0,0,zl
0,zl,zl,zl,0,zl,0,0,0,zl
0,zl,zl,zl,0,0,zl,0,0,zl
0,zl,zl,0,zl,zl,0,0,0,zl
0,zl,zl,0,zl,0,zl,0,0,zl
0,zl,zl,0,zl,0,0,zl,0,zl
0,zl,zl,0,zl,0,0,0,zl,zl
0,zl,zl,0,0,zl,zl,0,0,zl
0,zl,zl,0,0,zl,0,zl,0,zl
0,zl,zl,0,0,zl,0,0,zl,zl
0,zl,zl,0,0,0,zl,zl,0,zl
0,zl,0,zl,0,zl,0,zl,0,zl
0,0,zl,0,zl,0,zl,0,zl,zl
0,zl,zl,zl,zl,zl,0,0,0,zl
0,zl,zl,zl,zl,0,zl,0,0,zl
0,zl,zl,zl,zl,0,0,zl,0,zl
0,zl,zl,zl,zl,0,0,0,zl,zl
0,zl,zl,zl,0,zl,zl,0,0,zl
0,zl,zl,zl,0,zl,0,zl,0,zl
0,zl,zl,0,zl,zl,zl,0,0,zl
0,zl,zl,0,zl,zl,0,zl,0,zl
0,zl,zl,0,zl,0,zl,zl,0,zl
0,zl,zl,0,zl,0,zl,0,zl,zl
0,zl,zl,zl,zl,zl,zl,zl,0,zl
0,zl,zl,zl,zl,zl,zl,0,zl,zl
zl,0,0,0,0,0,0,0,0,zl
zl,zl,zl,zl,zl,zl,0,0,0,zl
zl,zl,zl,zl,zl,0,zl,0,0,zl
zl,zl,zl,zl,zl,0,0,zl,0,zl
zl,zl,zl,zl,zl,0,0,0,zl,zl
zl,zl,zl,zl,0,zl,zl,0,0,zl
zl,zl,zl,zl,0,zl,0,zl,0,zl
zl,zl,zl,0,zl,zl,zl,0,0,zl
zl,zl,zl,0,zl,zl,0,zl,0,zl
zl,zl,zl,0,zl,0,zl,zl,0,zl
zl,zl,zl,0,zl,0,zl,0,zl,zl
#c83
0,zm,zm,zm,0,0,0,0,0,zm
0,zm,zm,0,zm,0,0,0,0,zm
0,zm,zm,0,0,zm,0,0,0,zm
0,zm,zm,0,0,0,zm,0,0,zm
0,zm,zm,0,0,0,0,zm,0,zm
0,zm,zm,0,0,0,0,0,zm,zm
0,zm,0,zm,0,zm,0,0,0,zm
0,zm,0,zm,0,0,zm,0,0,zm
0,zm,0,0,zm,0,zm,0,0,zm
0,0,zm,0,zm,0,zm,0,0,zm
0,zm,zm,zm,zm,0,0,0,0,zm
0,zm,zm,zm,0,zm,0,0,0,zm
0,zm,zm,zm,0,0,zm,0,0,zm
0,zm,zm,0,zm,zm,0,0,0,zm
0,zm,zm,0,zm,0,zm,0,0,zm
0,zm,zm,0,zm,0,0,zm,0,zm
0,zm,zm,0,zm,0,0,0,zm,zm
0,zm,zm,0,0,zm,zm,0,0,zm
0,zm,zm,0,0,zm,0,zm,0,zm
0,zm,zm,0,0,zm,0,0,zm,zm
0,zm,zm,0,0,0,zm,zm,0,zm
0,zm,0,zm,0,zm,0,zm,0,zm
0,0,zm,0,zm,0,zm,0,zm,zm
0,zm,zm,zm,zm,zm,0,0,0,zm
0,zm,zm,zm,zm,0,zm,0,0,zm
0,zm,zm,zm,zm,0,0,zm,0,zm
0,zm,zm,zm,zm,0,0,0,zm,zm
0,zm,zm,zm,0,zm,zm,0,0,zm
0,zm,zm,zm,0,zm,0,zm,0,zm
0,zm,zm,0,zm,zm,zm,0,0,zm
0,zm,zm,0,zm,zm,0,zm,0,zm
0,zm,zm,0,zm,0,zm,zm,0,zm
0,zm,zm,0,zm,0,zm,0,zm,zm
zm,zm,zm,zm,zm,0,0,0,0,zm
zm,zm,zm,zm,0,zm,0,0,0,zm
zm,zm,zm,zm,0,0,zm,0,0,zm
zm,zm,zm,0,zm,zm,0,0,0,zm
zm,zm,zm,0,zm,0,zm,0,0,zm
zm,zm,zm,0,zm,0,0,zm,0,zm
zm,zm,zm,0,zm,0,0,0,zm,zm
zm,zm,zm,0,0,zm,zm,0,0,zm
zm,zm,zm,0,0,zm,0,zm,0,zm
zm,zm,zm,0,0,zm,0,0,zm,zm
zm,zm,zm,0,0,0,zm,zm,0,zm
zm,zm,0,zm,0,zm,0,zm,0,zm
zm,0,zm,0,zm,0,zm,0,zm,zm
zm,zm,zm,zm,zm,zm,0,0,0,zm
zm,zm,zm,zm,zm,0,zm,0,0,zm
zm,zm,zm,zm,zm,0,0,zm,0,zm
zm,zm,zm,zm,zm,0,0,0,zm,zm
zm,zm,zm,zm,0,zm,zm,0,0,zm
zm,zm,zm,zm,0,zm,0,zm,0,zm
zm,zm,zm,0,zm,zm,zm,0,0,zm
zm,zm,zm,0,zm,zm,0,zm,0,zm
zm,zm,zm,0,zm,0,zm,zm,0,zm
zm,zm,zm,0,zm,0,zm,0,zm,zm
#c87
0,zo,zo,zo,0,0,0,0,0,zo
0,zo,zo,0,zo,0,0,0,0,zo
0,zo,zo,0,0,zo,0,0,0,zo
0,zo,zo,0,0,0,zo,0,0,zo
0,zo,zo,0,0,0,0,zo,0,zo
0,zo,zo,0,0,0,0,0,zo,zo
0,zo,0,zo,0,zo,0,0,0,zo
0,zo,0,zo,0,0,zo,0,0,zo
0,zo,0,0,zo,0,zo,0,0,zo
0,0,zo,0,zo,0,zo,0,0,zo
0,zo,zo,zo,zo,0,0,0,0,zo
0,zo,zo,zo,0,zo,0,0,0,zo
0,zo,zo,zo,0,0,zo,0,0,zo
0,zo,zo,0,zo,zo,0,0,0,zo
0,zo,zo,0,zo,0,zo,0,0,zo
0,zo,zo,0,zo,0,0,zo,0,zo
0,zo,zo,0,zo,0,0,0,zo,zo
0,zo,zo,0,0,zo,zo,0,0,zo
0,zo,zo,0,0,zo,0,zo,0,zo
0,zo,zo,0,0,zo,0,0,zo,zo
0,zo,zo,0,0,0,zo,zo,0,zo
0,zo,0,zo,0,zo,0,zo,0,zo
0,0,zo,0,zo,0,zo,0,zo,zo
0,zo,zo,zo,zo,zo,0,0,0,zo
0,zo,zo,zo,zo,0,zo,0,0,zo
0,zo,zo,zo,zo,0,0,zo,0,zo
0,zo,zo,zo,zo,0,0,0,zo,zo
0,zo,zo,zo,0,zo,zo,0,0,zo
0,zo,zo,zo,0,zo,0,zo,0,zo
0,zo,zo,0,zo,zo,zo,0,0,zo
0,zo,zo,0,zo,zo,0,zo,0,zo
0,zo,zo,0,zo,0,zo,zo,0,zo
0,zo,zo,0,zo,0,zo,0,zo,zo
zo,zo,zo,zo,zo,0,0,0,0,zo
zo,zo,zo,zo,0,zo,0,0,0,zo
zo,zo,zo,zo,0,0,zo,0,0,zo
zo,zo,zo,0,zo,zo,0,0,0,zo
zo,zo,zo,0,zo,0,zo,0,0,zo
zo,zo,zo,0,zo,0,0,zo,0,zo
zo,zo,zo,0,zo,0,0,0,zo,zo
zo,zo,zo,0,0,zo,zo,0,0,zo
zo,zo,zo,0,0,zo,0,zo,0,zo
zo,zo,zo,0,0,zo,0,0,zo,zo
zo,zo,zo,0,0,0,zo,zo,0,zo
zo,zo,0,zo,0,zo,0,zo,0,zo
zo,0,zo,0,zo,0,zo,0,zo,zo
zo,zo,zo,zo,zo,zo,0,0,0,zo
zo,zo,zo,zo,zo,0,zo,0,0,zo
zo,zo,zo,zo,zo,0,0,zo,0,zo
zo,zo,zo,zo,zo,0,0,0,zo,zo
zo,zo,zo,zo,0,zo,zo,0,0,zo
zo,zo,zo,zo,0,zo,0,zo,0,zo
zo,zo,zo,0,zo,zo,zo,0,0,zo
zo,zo,zo,0,zo,zo,0,zo,0,zo
zo,zo,zo,0,zo,0,zo,zo,0,zo
zo,zo,zo,0,zo,0,zo,0,zo,zo
zo,zo,zo,zo,zo,zo,zo,zo,0,zo
zo,zo,zo,zo,zo,zo,zo,0,zo,zo
zo,zo,zo,zo,zo,zo,zo,zo,zo,zo
#c89
0,zp,zp,zp,0,0,0,0,0,zp
0,zp,zp,0,zp,0,0,0,0,zp
0,zp,zp,0,0,zp,0,0,0,zp
0,zp,zp,0,0,0,zp,0,0,zp
0,zp,zp,0,0,0,0,zp,0,zp
0,zp,zp,0,0,0,0,0,zp,zp
0,zp,0,zp,0,zp,0,0,0,zp
0,zp,0,zp,0,0,zp,0,0,zp
0,zp,0,0,zp,0,zp,0,0,zp
0,0,zp,0,zp,0,zp,0,0,zp
0,zp,zp,zp,zp,0,0,0,0,zp
0,zp,zp,zp,0,zp,0,0,0,zp
0,zp,zp,zp,0,0,zp,0,0,zp
0,zp,zp,0,zp,zp,0,0,0,zp
0,zp,zp,0,zp,0,zp,0,0,zp
0,zp,zp,0,zp,0,0,zp,0,zp
0,zp,zp,0,zp,0,0,0,zp,zp
0,zp,zp,0,0,zp,zp,0,0,zp
0,zp,zp,0,0,zp,0,zp,0,zp
0,zp,zp,0,0,zp,0,0,zp,zp
0,zp,zp,0,0,0,zp,zp,0,zp
0,zp,0,zp,0,zp,0,zp,0,zp
0,0,zp,0,zp,0,zp,0,zp,zp
0,zp,zp,zp,zp,zp,0,0,0,zp
0,zp,zp,zp,zp,0,zp,0,0,zp
0,zp,zp,zp,zp,0,0,zp,0,zp
0,zp,zp,zp,zp,0,0,0,zp,zp
0,zp,zp,zp,0,zp,zp,0,0,zp
0,zp,zp,zp,0,zp,0,zp,0,zp
0,zp,zp,0,zp,zp,zp,0,0,zp
0,zp,zp,0,zp,zp,0,zp,0,zp
0,zp,zp,0,zp,0,zp,zp,0,zp
0,zp,zp,0,zp,0,zp,0,zp,zp
0,zp,zp,zp,zp,zp,zp,zp,0,zp
0,zp,zp,zp,zp,zp,zp,0,zp,zp
zp,0,0,0,0,0,0,0,0,zp
zp,zp,zp,zp,zp,zp,0,0,0,zp
zp,zp,zp,zp,zp,0,zp,0,0,zp
zp,zp,zp,zp,zp,0,0,zp,0,zp
zp,zp,zp,zp,zp,0,0,0,zp,zp
zp,zp,zp,zp,0,zp,zp,0,0,zp
zp,zp,zp,zp,0,zp,0,zp,0,zp
zp,zp,zp,0,zp,zp,zp,0,0,zp
zp,zp,zp,0,zp,zp,0,zp,0,zp
zp,zp,zp,0,zp,0,zp,zp,0,zp
zp,zp,zp,0,zp,0,zp,0,zp,zp
zp,zp,zp,zp,zp,zp,zp,zp,0,zp
zp,zp,zp,zp,zp,zp,zp,0,zp,zp
#c141
0,zs,zs,zs,0,0,0,0,0,zs
0,zs,zs,0,zs,0,0,0,0,zs
0,zs,zs,0,0,zs,0,0,0,zs
0,zs,zs,0,0,0,zs,0,0,zs
0,zs,zs,0,0,0,0,zs,0,zs
0,zs,zs,0,0,0,0,0,zs,zs
0,zs,0,zs,0,zs,0,0,0,zs
0,zs,0,zs,0,0,zs,0,0,zs
0,zs,0,0,zs,0,zs,0,0,zs
0,0,zs,0,zs,0,zs,0,0,zs
0,zs,zs,zs,zs,0,0,0,0,zs
0,zs,zs,zs,0,zs,0,0,0,zs
0,zs,zs,zs,0,0,zs,0,0,zs
0,zs,zs,0,zs,zs,0,0,0,zs
0,zs,zs,0,zs,0,zs,0,0,zs
0,zs,zs,0,zs,0,0,zs,0,zs
0,zs,zs,0,zs,0,0,0,zs,zs
0,zs,zs,0,0,zs,zs,0,0,zs
0,zs,zs,0,0,zs,0,zs,0,zs
0,zs,zs,0,0,zs,0,0,zs,zs
0,zs,zs,0,0,0,zs,zs,0,zs
0,zs,0,zs,0,zs,0,zs,0,zs
0,0,zs,0,zs,0,zs,0,zs,zs
0,zs,zs,zs,zs,zs,0,0,0,zs
0,zs,zs,zs,zs,0,zs,0,0,zs
0,zs,zs,zs,zs,0,0,zs,0,zs
0,zs,zs,zs,zs,0,0,0,zs,zs
0,zs,zs,zs,0,zs,zs,0,0,zs
0,zs,zs,zs,0,zs,0,zs,0,zs
0,zs,zs,0,zs,zs,zs,0,0,zs
0,zs,zs,0,zs,zs,0,zs,0,zs
0,zs,zs,0,zs,0,zs,zs,0,zs
0,zs,zs,0,zs,0,zs,0,zs,zs
0,zs,zs,zs,zs,zs,zs,zs,zs,zs
zs,0,0,0,0,0,0,0,0,zs
zs,zs,zs,zs,zs,zs,0,0,0,zs
zs,zs,zs,zs,zs,0,zs,0,0,zs
zs,zs,zs,zs,zs,0,0,zs,0,zs
zs,zs,zs,zs,zs,0,0,0,zs,zs
zs,zs,zs,zs,0,zs,zs,0,0,zs
zs,zs,zs,zs,0,zs,0,zs,0,zs
zs,zs,zs,0,zs,zs,zs,0,0,zs
zs,zs,zs,0,zs,zs,0,zs,0,zs
zs,zs,zs,0,zs,0,zs,zs,0,zs
zs,zs,zs,0,zs,0,zs,0,zs,zs
zs,zs,zs,zs,zs,zs,zs,0,0,zs
zs,zs,zs,zs,zs,zs,0,zs,0,zs
zs,zs,zs,zs,zs,0,zs,zs,0,zs
zs,zs,zs,zs,zs,0,zs,0,zs,zs
zs,zs,zs,zs,0,zs,zs,zs,0,zs
zs,zs,zs,0,zs,zs,zs,0,zs,zs
zs,zs,zs,zs,zs,zs,zs,zs,0,zs
zs,zs,zs,zs,zs,zs,zs,0,zs,zs
zs,zs,zs,zs,zs,zs,zs,zs,zs,zs
#universal
0,0,zz,0,zz,0,0,0,0,zz
0,zz,zz,zz,0,0,0,0,0,zz
0,zz,0,zz,0,zz,0,0,0,zz
0,zz,zz,zz,zz,0,0,0,0,zz
0,zz,zz,0,zz,zz,0,0,0,zz
0,zz,zz,zz,zz,zz,0,0,0,zz
0,zz,zz,zz,zz,0,zz,0,0,zz
0,zz,zz,zz,zz,0,0,zz,0,zz
0,zz,zz,zz,zz,0,0,0,zz,zz
0,zz,zz,zz,0,zz,zz,0,0,zz
0,zz,zz,zz,0,zz,0,zz,0,zz
0,zz,zz,0,zz,zz,zz,0,0,zz
0,zz,zz,0,zz,zz,0,zz,0,zz
0,zz,zz,0,zz,0,zz,zz,0,zz
0,zz,zz,0,zz,0,zz,0,zz,zz
0,zz,zz,zz,zz,zz,0,zz,0,zz
zz,zz,zz,0,0,0,0,0,0,zz
zz,zz,0,zz,0,0,0,0,0,zz
zz,zz,0,0,0,zz,0,0,0,zz
zz,0,zz,0,zz,0,0,0,0,zz
zz,zz,zz,zz,0,0,0,0,0,zz
zz,zz,zz,0,0,zz,0,0,0,zz
zz,zz,zz,0,0,0,0,zz,0,zz
zz,zz,zz,0,0,0,0,0,zz,zz
zz,zz,0,zz,0,0,zz,0,0,zz
zz,zz,0,0,zz,0,zz,0,0,zz
zz,0,zz,0,zz,0,zz,0,0,zz
zz,zz,zz,zz,zz,0,0,0,0,zz
zz,zz,zz,zz,0,zz,0,0,0,zz
zz,zz,zz,zz,0,0,zz,0,0,zz
zz,zz,zz,0,zz,zz,0,0,0,zz
zz,zz,zz,0,zz,0,zz,0,0,zz
zz,zz,zz,0,zz,0,0,zz,0,zz
zz,zz,zz,0,zz,0,0,0,zz,zz
zz,zz,zz,0,0,zz,zz,0,0,zz
zz,zz,zz,0,0,zz,0,zz,0,zz
zz,zz,zz,0,0,zz,0,0,zz,zz
zz,zz,zz,0,0,0,zz,zz,0,zz
zz,zz,0,zz,0,zz,0,zz,0,zz
zz,0,zz,0,zz,0,zz,0,zz,zz


#death
a,b,d,e,f,g,i,j,k,0

@COLORS

0 0 0 0
1 255 255 255
2 255 0 0
3 0 255 0
4 0 0 255
5 0 255 255
6 255 0 255
7 255 255 0
8 255 127 0
9 127 255 0
10 255 0 127
11 127 0 255
12 0 255 127
13 0 127 255
14 127 0 0
15 0 127 0
16 0 0 127
17 0 127 127
18 127 0 127
19 127 127 0
20 255 127 127
21 127 255 127
22 127 127 255
23 127 255 255
24 255 127 255
25 255 255 127
26 255 191 0
27 191 255 0
28 255 0 191
29 191 0 255
30 0 255 191
31 0 191 255
32 191 0 0
33 0 191 0
34 0 0 191
35 191 191 191
]]
    )
    f:close()
end

pattname = g.getdir("temp").."unit-fraction-orthogonal-spaceships.mc"
f = io.open(pattname, "w")
if f then
    f:write(
[[
[M2] (golly 3.3)
#R RainbowASOv1.3
#C
#C Spaceships of all unit-fraction speeds from c/1 to c/50,
#C with a scattering of slower speeds down to c/150.
#C Rules represented include B3/S23 and a wide variety
#C of other Life-like and isotropic non-totalistic rules.
#C The RainbowASOv1.3 "mashup rule" lets spaceships from 
#C different rules run simultaneously in the same pattern.
#C
#C Rule created and pattern compiled by Connor Steppie, 9 July 2017, 
#C with hyperbolic spaceship stunt-flying arrangement by
#C Adam P. Goucher.
#C http://www.conwaylife.com/forums/viewtopic.php?p=46271#p46271
#C
#C A more recent version of the RainbowASO rule, also by
#C Connor Steppie, can be found here (RainbowASOv3.1, 6 July 2018):
#C http://www.conwaylife.com/forums/viewtopic.php?p=61655#p61655
1 0 0 0 35
2 0 1 0 0
1 35 0 0 35
1 0 0 35 35
1 35 0 0 0
2 3 4 5 0
3 2 6 0 0
2 4 4 0 0
3 8 8 0 0
4 0 0 7 9
5 0 0 0 10
6 0 11 0 0
1 0 35 35 0
1 0 35 0 0
2 13 4 14 0
3 0 15 0 0
4 0 0 16 9
5 0 17 0 0
6 0 0 0 18
7 0 12 0 19
2 1 3 0 5
3 0 21 0 0
4 0 0 22 9
5 0 0 0 23
6 0 0 0 24
7 0 25 0 0
8 0 20 0 26
2 0 0 0 1
3 0 28 0 0
2 0 0 3 4
2 0 0 4 4
2 5 0 0 0
3 30 31 32 0
4 29 33 0 0
5 0 0 0 34
6 0 35 0 0
5 0 34 0 0
6 0 0 0 37
7 0 36 0 38
2 0 0 13 4
2 14 0 0 0
3 40 31 41 0
4 0 42 0 0
5 0 0 0 43
6 0 0 0 44
7 0 45 0 0
8 0 39 0 46
9 0 27 0 47
2 0 0 1 3
2 0 5 0 0
3 49 31 50 0
4 0 51 0 0
5 0 52 0 0
6 0 53 0 0
2 0 0 0 13
2 0 14 0 0
3 55 31 56 0
4 0 57 0 0
5 0 0 0 58
6 0 59 0 0
7 0 54 0 60
3 28 30 0 32
4 0 62 0 0
5 0 63 0 0
6 0 0 0 64
3 0 40 0 41
4 0 66 0 0
5 0 0 0 67
6 0 0 0 68
7 0 65 0 69
8 0 61 0 70
3 0 49 0 50
4 0 72 0 0
5 0 73 0 0
6 0 74 0 0
7 0 0 0 75
3 0 55 0 56
4 0 77 0 0
5 0 0 0 78
6 0 79 0 0
4 0 29 0 0
5 0 81 0 0
6 0 0 0 82
7 0 80 0 83
8 0 76 0 84
9 0 71 0 85
10 0 48 0 86
11 0 87 0 0
12 0 0 0 88
13 0 0 0 89
1 35 0 35 0
2 4 91 0 5
3 8 92 0 0
4 0 0 9 93
5 0 0 94 0
1 0 0 23 0
2 0 0 0 96
2 0 0 96 96
3 0 0 97 98
4 0 0 0 99
5 0 0 100 0
6 95 0 101 0
7 0 0 12 102
8 0 0 103 0
9 0 0 104 0
10 0 0 105 0
11 0 0 106 0
6 95 0 101 18
1 23 0 0 0
1 23 23 0 0
1 0 23 0 23
1 23 0 0 23
2 109 110 111 112
1 23 23 0 23
2 111 96 114 0
3 113 115 0 0
4 0 116 0 0
5 117 0 0 0
5 94 0 0 0
6 118 0 119 0
6 118 0 119 24
1 22 0 0 0
2 0 122 0 0
1 0 0 22 22
1 0 0 22 0
1 22 0 22 0
2 124 125 126 126
3 0 0 123 127
4 0 0 0 128
2 0 125 0 0
1 22 22 0 0
2 131 122 0 0
3 130 132 0 0
4 0 133 0 0
5 129 0 134 0
6 135 0 95 0
7 108 120 121 136
1 0 21 0 21
2 0 0 138 0
1 0 21 21 0
1 21 0 21 0
2 0 0 140 141
1 0 21 0 0
1 21 0 0 21
1 21 0 0 0
2 143 144 138 145
1 0 0 21 0
2 147 147 147 147
3 139 142 146 148
2 143 0 0 0
2 143 145 0 0
3 150 151 0 0
4 0 149 0 152
5 153 0 0 0
6 0 0 154 0
6 0 35 154 0
3 31 31 0 0
1 0 35 35 35
2 0 0 4 158
3 31 159 0 56
4 157 160 0 0
5 0 0 161 0
1 0 20 0 0
1 0 20 0 20
1 0 20 20 0
1 20 20 20 20
2 163 164 165 166
1 0 0 0 20
1 20 20 0 20
1 0 0 20 0
2 168 0 169 170
3 0 0 167 171
1 20 0 20 0
1 20 0 0 20
2 173 166 174 166
1 0 20 20 20
1 20 0 0 0
2 164 173 176 177
2 168 164 0 0
2 163 0 0 0
3 175 178 179 180
4 0 172 0 181
5 0 0 182 0
6 162 0 183 0
7 136 155 156 184
8 137 0 185 0
6 162 0 183 37
2 0 0 4 91
3 31 188 0 50
4 157 189 0 0
5 190 0 0 0
6 0 0 191 0
6 0 0 191 44
1 0 0 0 19
2 0 0 0 194
2 0 0 194 0
3 0 0 195 196
1 19 19 19 0
1 19 19 0 19
2 0 198 0 199
1 19 19 0 0
1 19 0 0 0
2 201 202 199 202
3 200 203 0 0
4 0 197 0 204
5 205 0 0 0
5 0 0 190 0
6 206 0 207 0
7 187 192 193 208
1 0 0 18 0
1 18 18 18 18
2 0 210 0 211
3 0 0 212 0
4 0 0 0 213
1 18 0 0 0
1 0 18 0 0
2 0 215 0 216
1 0 0 18 18
2 215 0 218 210
2 0 0 218 210
3 217 219 0 220
1 18 0 18 18
2 0 216 0 222
2 0 0 215 0
1 18 18 18 0
2 0 225 0 0
3 223 224 226 0
4 0 221 0 227
5 214 0 228 0
6 229 0 0 0
6 229 53 0 0
1 0 0 0 17
1 0 0 17 0
2 0 0 232 233
1 17 17 0 17
2 0 0 235 233
3 0 0 234 236
1 0 17 0 17
1 17 0 17 0
1 0 17 0 0
1 17 0 0 0
2 238 239 240 241
1 0 17 17 17
2 239 239 243 241
3 242 244 0 0
4 0 237 0 245
5 246 0 0 0
6 191 0 247 0
7 208 230 231 248
8 209 0 249 0
9 186 0 250 0
6 191 59 247 0
1 0 0 0 16
1 0 16 0 0
2 0 253 0 254
1 0 0 16 0
1 16 0 0 0
2 256 0 257 0
2 0 0 0 253
1 16 0 16 0
2 0 0 257 260
3 255 258 259 261
2 257 257 0 0
1 0 16 0 16
2 0 264 0 0
2 260 0 0 0
3 0 263 265 266
4 0 262 0 267
5 0 0 268 0
6 207 0 269 0
6 207 0 269 64
7 252 270 271 192
6 0 0 191 68
1 0 0 15 0
1 0 0 0 15
2 0 0 274 275
2 0 0 274 274
3 0 0 276 277
1 15 0 15 0
1 15 15 15 15
1 15 0 0 0
1 0 15 0 0
2 279 280 281 282
2 0 279 281 281
3 283 284 0 0
4 0 278 0 285
5 286 0 0 0
6 287 0 207 0
1 0 0 14 0
2 0 0 0 289
1 14 0 0 0
2 0 0 291 0
3 0 0 290 292
1 0 0 0 14
2 294 0 0 289
1 0 14 0 14
1 0 14 0 0
2 296 291 297 291
2 291 0 0 0
3 295 298 0 299
4 0 293 0 300
5 0 0 301 0
6 302 0 0 0
7 273 288 288 303
8 272 0 304 0
6 302 74 0 0
1 0 0 0 13
2 0 0 0 307
2 0 0 307 0
3 0 0 308 309
1 13 0 13 13
1 0 0 13 0
1 13 13 13 13
1 13 0 13 0
2 311 312 313 314
2 0 307 0 0
1 13 0 0 13
2 317 0 0 0
3 0 315 316 318
4 0 310 0 319
5 320 0 0 0
6 191 0 321 0
6 191 79 321 0
1 0 12 12 0
1 12 0 12 0
2 0 324 0 325
1 0 0 12 12
1 0 0 12 0
2 327 328 327 328
1 0 12 0 0
2 0 330 0 0
3 326 329 331 0
4 0 0 0 332
5 0 0 333 0
6 207 0 334 0
7 306 322 323 335
6 207 0 334 82
4 33 189 0 0
5 338 0 0 0
6 0 0 339 0
1 0 11 11 0
1 0 11 0 0
2 0 341 0 342
1 11 0 0 11
1 0 0 11 0
1 11 0 0 0
2 344 345 346 0
3 343 347 0 0
4 0 0 0 348
5 349 0 0 0
4 42 189 0 0
5 0 0 351 0
6 350 0 352 0
7 337 340 340 353
8 336 0 354 0
9 305 0 355 0
10 251 0 356 0
1 10 0 10 0
2 0 0 358 0
3 0 0 0 359
1 0 0 0 10
2 0 361 0 0
1 0 0 10 0
2 363 363 363 0
1 10 0 0 0
2 365 0 0 0
3 362 364 0 366
4 0 360 0 367
5 0 0 368 0
6 369 0 0 0
4 51 189 0 0
5 371 0 0 0
1 0 9 0 0
2 0 0 0 373
3 0 374 0 0
1 0 0 9 9
2 373 376 0 376
1 0 0 9 0
1 9 9 0 0
2 0 378 379 378
2 373 0 0 0
3 377 380 381 0
4 0 0 375 382
5 383 0 0 0
6 372 0 384 0
7 353 370 370 385
4 57 189 0 0
5 0 0 387 0
1 0 0 0 8
2 0 0 0 389
1 0 8 0 0
1 8 0 8 0
2 0 0 391 392
3 0 0 390 393
2 0 391 0 0
2 389 392 0 0
3 395 396 0 0
4 0 394 0 397
5 0 0 398 0
6 388 0 399 0
4 62 189 0 0
5 401 0 0 0
6 0 0 402 0
7 385 400 400 403
8 386 0 404 0
1 0 0 0 7
1 0 0 7 0
2 0 0 406 407
3 0 0 0 408
1 7 7 0 0
1 7 7 7 0
2 406 410 406 411
3 0 412 0 0
2 407 406 0 0
2 410 407 410 0
3 414 415 0 0
4 409 0 413 416
5 417 0 0 0
4 66 189 0 0
5 0 0 419 0
6 418 0 420 0
1 0 0 6 0
2 0 0 0 422
3 0 0 0 423
1 0 0 0 6
1 6 0 0 0
1 0 6 0 6
2 425 426 427 0
2 0 426 0 0
3 0 428 0 429
4 0 424 0 430
5 0 0 431 0
6 432 0 0 0
7 403 421 421 433
4 72 189 0 0
5 435 0 0 0
1 0 0 5 0
1 0 5 0 5
2 437 0 438 437
1 0 5 5 0
2 440 0 0 0
3 0 439 0 441
4 0 0 0 442
5 443 0 0 0
6 436 0 444 0
4 77 189 0 0
5 0 0 446 0
1 0 0 4 0
2 0 0 0 448
1 4 0 0 0
2 0 450 0 0
1 0 4 0 0
2 452 448 0 0
3 0 449 451 453
4 0 0 0 454
5 0 0 455 0
6 447 0 456 0
7 433 445 445 457
8 434 0 458 0
9 405 0 459 0
1 0 0 0 1
2 0 0 0 461
1 1 1 0 0
2 0 0 0 463
3 0 0 462 464
1 1 0 1 1
2 0 0 466 463
1 0 0 1 1
2 0 0 468 0
3 0 0 467 469
4 0 0 465 470
5 0 0 471 0
1 1 1 1 1
1 0 1 0 0
2 0 473 0 474
2 0 0 0 468
3 475 476 0 0
1 0 1 0 1
1 1 1 1 0
2 478 0 479 468
1 1 0 1 0
2 0 481 463 0
3 480 482 0 0
4 477 483 0 0
5 484 0 0 0
6 472 0 485 0
1 0 3 0 0
2 0 0 0 487
1 0 0 0 3
1 0 0 3 0
2 489 0 0 490
2 0 487 0 0
2 489 0 0 0
3 488 491 492 493
4 0 0 0 494
5 495 0 0 0
3 40 188 41 50
4 0 497 0 0
5 0 0 498 0
6 496 0 499 0
7 457 486 486 500
2 0 468 0 474
3 0 0 0 502
1 1 0 0 0
2 461 0 504 478
2 468 0 461 504
3 0 0 505 506
1 0 0 1 0
2 0 508 0 463
2 0 468 0 0
3 0 509 0 510
1 1 0 0 1
2 0 0 512 0
2 504 0 0 0
3 513 514 514 0
4 503 507 511 515
5 0 0 516 0
2 478 0 474 0
3 0 0 0 518
4 0 0 0 519
2 0 0 508 0
2 0 474 0 0
1 1 1 0 1
2 474 478 0 523
3 0 521 522 524
2 0 474 468 0
2 463 508 0 481
2 508 0 461 479
2 504 0 508 0
3 526 527 528 529
1 0 1 1 1
2 0 478 0 531
2 0 461 0 0
2 461 478 504 0
3 0 532 533 534
2 0 0 474 466
2 478 0 504 0
2 504 0 463 0
2 508 0 0 481
3 536 537 538 539
4 525 530 535 540
5 520 0 541 0
6 517 0 542 0
2 468 504 461 0
2 478 0 0 0
3 533 544 0 545
4 0 546 0 0
2 473 0 508 468
2 481 0 531 0
3 462 521 548 549
3 0 522 0 0
2 504 512 0 0
2 468 0 466 0
2 0 0 461 468
2 461 504 474 0
3 552 553 554 555
4 0 550 551 556
5 547 0 557 0
2 461 468 0 0
2 0 0 478 0
2 468 504 466 0
3 559 560 462 561
2 481 466 468 0
1 0 1 1 0
2 468 0 564 0
2 463 461 0 0
2 481 0 0 0
3 563 565 566 567
4 0 562 551 568
5 569 0 0 0
6 558 0 570 0
7 500 543 543 571
8 501 0 572 0
2 0 0 461 0
2 504 478 0 461
3 0 574 522 575
2 468 0 481 481
3 0 0 577 0
2 0 504 0 461
3 0 579 0 0
2 0 478 508 0
2 508 0 461 0
2 474 468 461 504
2 508 0 0 0
3 581 582 583 584
4 576 578 580 585
2 478 504 473 0
2 474 0 0 0
2 564 504 0 0
3 587 521 588 589
4 0 590 0 0
5 586 0 591 0
3 0 0 462 513
4 0 0 0 593
2 478 0 461 508
2 564 508 463 504
3 522 595 522 596
2 0 474 0 508
2 531 0 481 0
2 0 512 0 0
3 598 599 600 514
4 0 597 0 601
5 594 0 602 0
6 592 0 603 0
3 0 462 0 522
2 0 466 0 468
2 0 0 466 0
3 574 0 606 607
4 0 0 605 608
2 0 478 0 0
3 0 0 0 610
2 474 461 0 474
2 0 481 461 504
2 474 523 508 481
3 612 613 614 514
3 0 0 0 462
2 461 468 461 473
2 508 508 0 512
3 617 0 618 0
4 611 615 616 619
5 609 0 620 0
2 474 463 0 478
2 512 0 0 481
2 474 468 0 468
2 468 504 504 0
3 622 623 624 625
3 0 610 0 0
2 461 504 0 0
3 628 0 0 0
4 551 626 627 629
5 630 0 0 0
6 621 0 631 0
7 571 604 604 632
1 0 0 2 2
2 0 0 634 0
3 0 0 635 0
4 0 0 636 0
5 0 0 637 0
3 0 0 554 0
4 0 0 0 639
3 0 0 462 469
4 0 0 0 641
5 0 0 640 642
6 0 0 638 643
2 0 0 508 508
3 0 0 645 0
4 0 0 616 646
5 0 0 0 647
3 0 0 574 0
4 0 0 0 649
5 0 0 0 650
6 0 0 648 651
7 0 0 644 652
1 0 0 2 0
1 2 0 2 0
2 654 655 0 0
3 0 0 0 656
4 0 0 0 657
5 658 0 0 0
6 659 0 638 643
2 654 0 0 0
3 661 0 0 0
4 662 0 0 0
5 663 0 0 0
2 0 461 461 481
3 0 665 0 538
2 481 0 481 463
2 512 0 478 512
2 474 0 474 504
3 667 668 588 669
4 666 670 0 0
2 0 0 508 473
2 0 0 481 468
2 508 504 0 0
2 504 508 0 0
3 672 673 674 675
2 461 504 523 474
2 0 466 504 481
2 474 0 463 0
3 677 678 679 588
4 676 680 0 0
5 671 681 0 0
6 664 682 648 651
7 632 660 660 683
2 0 504 474 504
3 607 0 685 0
4 686 0 0 0
2 461 468 512 508
2 479 478 474 0
3 688 689 0 0
2 564 504 474 0
2 463 512 474 504
3 691 692 0 0
4 690 693 0 0
5 687 694 0 0
2 564 508 0 0
2 0 0 461 461
2 474 473 0 0
2 463 504 0 0
3 696 697 698 699
4 0 700 0 0
5 0 701 0 0
4 0 0 649 0
5 0 0 650 703
6 695 702 0 704
2 508 504 481 0
2 508 0 463 468
2 474 508 0 504
2 0 468 461 504
3 706 707 708 709
2 481 0 463 0
3 0 0 711 0
3 555 0 0 0
4 710 712 0 713
5 714 0 0 0
2 468 564 504 0
2 481 466 466 504
2 478 481 0 0
2 468 0 474 0
3 716 717 718 719
2 481 463 0 0
2 0 474 481 481
2 504 504 0 0
3 721 722 0 723
4 720 724 0 0
2 504 466 0 0
2 481 479 512 481
2 461 508 474 0
3 726 727 0 728
2 468 508 0 504
2 473 0 0 0
3 730 0 731 0
4 729 732 0 0
5 725 733 0 0
3 0 0 0 554
4 0 0 0 735
3 0 0 476 521
4 0 0 0 737
5 0 0 736 738
4 0 0 616 0
5 0 0 0 740
6 715 734 739 741
7 683 705 705 742
8 633 653 684 743
6 0 0 0 704
6 0 0 739 741
7 0 0 745 746
2 0 0 1 4
3 0 0 748 0
4 0 0 0 749
5 0 0 0 750
6 0 0 751 0
2 0 0 0 490
3 0 0 753 0
4 0 0 754 0
5 0 0 755 0
3 0 0 0 469
4 0 0 0 757
5 0 0 758 0
6 0 0 756 759
7 0 0 752 760
2 481 0 504 0
3 699 762 0 610
3 0 533 0 0
4 0 763 0 764
2 508 461 0 466
2 463 508 0 531
2 461 474 463 479
2 0 504 463 523
3 766 767 768 769
2 461 0 0 0
2 478 474 474 0
2 508 481 463 0
3 771 772 773 0
2 504 0 504 0
3 775 0 0 0
2 474 508 474 0
3 777 0 0 0
4 770 774 776 778
5 765 779 0 0
2 463 0 0 0
3 781 0 0 0
4 782 0 0 0
2 461 504 0 463
2 461 512 481 478
2 0 461 508 474
3 0 784 785 786
2 504 0 481 0
3 567 0 788 0
4 787 789 0 0
5 783 790 0 0
6 780 791 751 0
2 0 91 0 91
2 14 13 0 0
3 793 0 794 0
4 0 795 0 0
5 0 796 0 0
6 797 0 756 759
7 742 792 792 798
1 3 0 0 0
2 800 0 487 487
2 800 0 0 0
3 801 802 0 0
4 803 0 0 0
5 804 0 0 0
2 0 478 0 481
2 0 481 0 478
2 0 531 0 481
2 463 466 0 478
3 806 807 808 809
2 0 0 0 474
2 0 0 473 504
3 811 812 0 0
4 0 810 0 813
5 814 0 0 0
2 0 0 448 448
3 0 0 816 0
4 0 0 817 0
5 0 0 0 818
6 805 815 819 751
1 0 0 0 4
2 452 0 821 0
3 822 0 0 0
4 823 0 0 0
5 0 824 0 0
2 0 91 14 13
3 793 0 826 0
4 0 827 0 0
5 0 828 0 0
2 0 0 0 437
3 0 0 830 0
4 0 0 831 0
5 0 0 832 0
6 825 829 0 833
7 798 820 820 834
8 747 761 799 835
9 573 0 744 836
6 0 0 819 751
6 0 0 0 833
7 0 0 838 839
5 0 0 750 0
2 0 0 425 0
2 0 0 425 422
3 0 0 842 843
4 0 0 844 0
5 0 0 0 845
6 0 0 841 846
7 0 0 847 752
1 5 5 0 0
2 440 849 0 0
2 437 0 0 0
3 850 851 0 0
4 852 0 0 0
5 853 0 0 0
6 0 854 841 846
2 0 91 1 3
3 793 0 856 0
3 50 0 0 0
4 0 857 0 858
5 859 0 0 0
1 6 6 0 0
2 0 861 0 0
2 426 0 0 0
3 862 863 0 0
4 864 0 0 0
5 0 865 0 0
6 860 866 751 0
7 834 855 855 867
3 793 0 793 0
3 794 0 0 0
4 0 869 0 870
5 0 871 0 0
2 0 0 407 0
3 0 0 0 873
4 0 0 874 0
5 0 0 875 0
6 872 0 876 841
1 0 7 0 7
2 0 878 0 0
1 7 0 0 0
2 878 0 880 0
1 0 7 7 7
2 0 0 0 882
2 407 0 878 407
3 879 881 883 884
2 0 880 0 0
2 880 880 0 0
3 886 887 0 0
4 885 0 888 0
5 889 0 0 0
3 21 0 0 0
4 0 869 0 891
5 892 0 0 0
1 0 0 8 8
2 0 0 894 894
3 0 0 0 895
4 0 0 896 0
5 0 0 0 897
6 890 893 898 751
7 867 877 877 899
8 840 848 868 900
6 0 0 876 841
6 0 0 898 751
7 0 0 902 903
2 0 0 0 378
2 0 0 378 0
3 0 0 905 906
4 0 0 907 0
5 0 0 908 0
6 0 0 0 909
2 0 0 363 0
3 0 0 0 911
4 0 0 912 0
5 0 0 0 913
6 0 0 841 914
7 0 0 910 915
1 8 0 0 0
2 917 391 391 917
3 0 918 0 0
4 919 0 0 0
5 0 920 0 0
3 826 0 0 0
4 0 869 0 922
5 0 923 0 0
6 921 924 0 909
1 0 9 0 9
1 9 0 9 0
2 0 926 0 927
2 0 0 927 0
2 373 0 0 373
3 928 929 930 381
4 931 0 0 0
5 932 0 0 0
6 0 933 841 914
7 899 925 925 934
3 856 0 50 0
4 0 869 0 936
5 937 0 0 0
2 361 363 0 0
1 0 0 10 10
2 363 940 365 0
3 939 941 0 0
4 942 0 0 0
5 0 943 0 0
6 938 944 751 0
4 0 869 0 795
5 0 946 0 0
2 0 0 345 0
3 0 0 0 948
4 0 0 949 0
5 0 0 950 0
6 947 0 951 841
7 934 945 945 952
8 904 916 935 953
9 0 0 901 954
10 460 0 837 955
6 0 0 951 841
7 0 0 752 957
2 0 0 0 328
2 0 0 328 0
3 0 0 959 960
4 0 0 961 0
5 0 0 0 962
6 0 0 963 751
1 0 0 13 13
2 0 0 0 965
2 0 0 312 0
3 0 0 966 967
4 0 0 968 0
5 0 0 969 0
6 0 0 0 970
7 0 0 964 971
1 0 0 0 11
2 0 973 0 342
2 344 0 341 0
3 974 975 0 0
4 976 0 0 0
5 977 0 0 0
3 793 0 21 0
4 0 869 0 979
5 980 0 0 0
6 978 981 963 751
2 0 325 330 327
2 325 0 324 0
3 983 984 0 0
4 985 0 0 0
5 0 986 0 0
4 0 869 0 827
5 0 988 0 0
6 987 989 0 970
7 952 982 982 990
1 13 0 0 0
2 317 313 992 0
2 311 992 0 992
3 993 994 0 0
4 995 0 0 0
5 996 0 0 0
2 0 0 0 294
2 0 0 294 0
3 0 0 998 999
4 0 0 1000 0
5 0 0 0 1001
6 0 997 841 1002
4 0 869 0 857
4 0 858 0 0
5 1004 0 1005 0
2 294 297 0 289
1 14 14 0 0
2 1008 294 0 289
3 1007 1009 0 299
4 1010 0 0 0
5 0 1011 0 0
6 1006 1012 751 0
7 990 1003 1003 1013
8 958 972 991 1014
6 0 0 841 1002
7 0 0 1016 752
2 0 0 0 275
1 0 0 15 15
2 0 0 1019 274
3 0 0 1018 1020
4 0 0 1021 0
5 0 0 1022 0
6 0 0 1023 841
1 0 0 16 16
2 0 0 253 1025
3 0 0 0 1026
4 0 0 1027 0
5 0 0 0 1028
6 0 0 1029 751
7 0 0 1024 1030
4 0 869 0 869
4 0 870 0 0
5 0 1032 0 1033
6 1034 0 1023 841
2 0 275 0 282
2 0 274 280 281
2 0 275 0 0
2 1019 274 0 0
3 1036 1037 1038 1039
4 1040 0 0 0
5 1041 0 0 0
4 0 891 0 0
5 1032 0 1043 0
6 1042 1044 1029 751
7 1013 1035 1035 1045
1 16 16 0 0
2 1025 0 1047 0
2 253 253 0 257
3 1048 1049 0 0
3 255 258 0 0
4 1050 1051 0 0
5 0 1052 0 0
4 0 922 0 0
5 0 1032 0 1054
2 0 0 0 232
1 0 0 17 17
2 0 0 1057 233
3 0 0 1056 1058
4 0 0 1059 0
5 0 0 1060 0
6 1053 1055 0 1061
1 17 17 17 0
2 0 1063 0 232
2 1057 235 1057 233
2 0 240 0 0
1 17 17 0 0
2 1067 241 0 0
3 1064 1065 1066 1068
4 1069 0 0 0
5 1070 0 0 0
2 0 0 0 210
3 0 0 0 1072
3 0 0 1072 0
4 0 0 1073 1074
5 0 0 0 1075
6 0 1071 841 1076
7 1045 1062 1062 1077
8 1017 1031 1046 1078
9 0 0 1015 1079
6 0 0 0 1061
6 0 0 841 1076
7 0 0 1081 1082
4 0 0 197 0
5 0 0 1084 0
6 0 0 1085 841
7 0 0 752 1086
4 0 936 0 0
5 1032 0 1088 0
1 0 0 0 18
1 0 18 18 18
2 0 1090 1091 222
1 18 0 18 0
2 0 1093 216 0
3 1092 1094 0 0
2 0 1093 0 216
2 1090 0 1090 211
3 1096 1097 0 0
4 1095 1098 0 0
5 0 1099 0 0
6 1089 1100 751 0
2 0 0 210 0
3 1102 0 0 0
4 1103 0 0 0
5 1104 1032 0 796
6 1105 0 1085 841
7 1077 1101 1101 1106
2 0 199 0 199
1 0 19 0 19
1 0 19 19 19
2 1109 202 1110 202
3 1108 1111 0 0
4 1112 0 0 0
5 1113 0 0 0
4 0 979 0 0
5 1032 0 1115 0
2 0 0 0 168
1 0 0 20 20
2 0 0 1118 170
3 0 0 1117 1119
4 0 0 1120 0
5 0 0 0 1121
1 35 35 35 0
2 0 0 14 1123
3 0 0 1124 0
4 0 0 0 1125
5 0 0 0 1126
6 1114 1116 1122 1127
6 1114 1116 1122 751
1 20 20 20 0
1 20 20 0 0
2 163 1130 1131 166
2 1131 169 166 166
2 177 174 0 0
2 1118 165 0 0
3 1132 1133 1134 1135
2 177 0 1131 0
3 1137 0 180 0
4 1136 1138 0 0
5 0 1139 0 0
5 0 1032 0 1115
1 0 0 21 21
1 0 0 0 21
2 0 0 1142 1143
2 0 0 1143 147
3 0 0 1144 1145
4 0 0 1146 0
5 0 0 1147 0
6 1140 1141 0 1148
7 1106 1128 1129 1149
8 1083 1087 1107 1150
6 0 0 1122 1127
1 21 21 21 0
2 0 0 1153 143
2 0 0 143 141
3 0 0 1154 1155
4 0 0 1156 0
5 0 0 1157 0
6 0 0 0 1158
7 0 0 1152 1159
5 0 0 1126 0
1 0 22 0 22
2 0 0 0 1162
2 0 0 131 126
3 0 0 1163 1164
4 0 0 1165 0
5 0 0 0 1166
6 0 0 1161 1167
6 0 0 1127 0
7 0 0 1168 1169
6 1140 1141 0 1158
2 143 138 1142 141
1 21 0 21 21
2 143 0 1173 147
3 1172 1174 0 0
4 1175 0 0 0
5 1176 0 0 0
6 0 1177 1161 1167
1 0 0 0 22
2 0 0 0 1179
2 0 0 124 125
3 0 0 1180 1181
4 0 0 1182 0
5 0 0 0 1183
6 0 1177 841 1184
5 1032 0 828 0
1 0 22 0 0
2 0 1187 0 122
2 131 122 0 1187
3 1188 1189 0 0
4 1190 0 0 0
5 0 1191 0 0
6 1186 1192 751 0
7 1171 1178 1185 1193
6 1186 1192 1127 0
5 0 1032 0 859
1 0 0 23 23
1 23 0 23 23
2 0 0 1197 1198
2 0 0 109 0
3 0 0 1199 1200
4 0 0 1201 0
5 0 0 1202 0
6 1196 0 1203 1161
2 0 0 96 0
3 0 0 97 1205
4 0 0 1206 0
5 0 0 1207 0
6 1196 0 1208 841
1 0 23 23 0
1 0 0 0 23
1 0 23 23 23
1 0 23 0 0
2 1210 1211 1212 1213
2 109 0 109 0
2 0 1213 0 0
3 1214 1215 1216 0
4 1217 0 0 0
5 1218 0 0 0
5 1032 0 871 0
6 1219 1220 0 751
7 1195 1204 1209 1221
8 1160 1170 1194 1222
9 0 0 1151 1223
10 0 0 1080 1224
11 357 0 956 1225
6 0 0 1203 1161
7 0 0 1227 0
6 1219 1220 0 0
1 0 0 0 24
1 0 0 24 24
2 0 0 1230 1231
3 0 0 1232 0
4 0 0 1233 0
5 0 0 1234 0
6 0 0 0 1235
1 0 0 0 25
2 0 0 0 1237
3 0 0 0 1238
4 0 0 0 1239
2 0 0 1237 0
3 0 0 0 1241
4 0 0 1242 0
5 0 0 1240 1243
6 0 0 841 1244
7 1229 0 1236 1245
6 0 0 0 841
7 0 0 752 1247
8 1228 0 1246 1248
1 0 0 0 26
1 0 0 26 0
2 0 0 1250 1251
3 0 0 1252 0
4 0 0 1253 0
5 0 0 0 1254
6 0 0 1255 751
7 0 0 1256 0
1 0 0 27 0
2 0 0 1258 0
3 0 0 1259 1259
4 0 0 1260 0
5 0 0 0 1261
6 0 0 841 1262
7 0 0 1263 752
8 0 0 1257 1264
9 0 0 1249 1265
1 0 0 28 0
2 0 0 0 1267
3 0 0 0 1268
4 0 0 0 1269
1 0 0 0 28
2 0 0 1267 1271
2 0 0 1271 0
3 0 0 1272 1273
4 0 0 1274 0
5 0 0 1270 1275
6 0 0 1276 751
7 0 0 1247 1277
6 0 0 841 0
7 0 0 0 1279
8 0 0 1278 1280
6 0 0 0 751
7 0 0 1282 0
8 0 0 1248 1283
9 0 0 1281 1284
10 0 0 1266 1285
1 0 0 30 0
1 0 0 30 30
2 0 0 1287 1288
3 0 0 0 1289
4 0 0 0 1290
5 0 0 0 1291
6 0 0 751 1292
7 0 0 1279 1293
2 0 0 1288 1288
1 0 0 0 30
2 0 0 1288 1296
3 0 0 1295 1297
4 0 0 1298 0
5 0 0 1299 0
6 0 0 1300 841
1 0 0 31 0
1 0 0 0 31
2 0 0 1302 1303
3 0 0 1304 0
4 0 0 1305 0
5 0 0 0 1306
6 0 0 1307 751
7 0 0 1301 1308
8 0 0 1294 1309
1 0 0 32 32
2 0 0 1311 1311
1 0 0 32 0
2 0 0 1313 0
3 0 0 1312 1314
4 0 0 1315 0
5 0 0 0 1316
6 0 0 841 1317
7 0 0 0 1318
1 0 0 0 33
2 0 0 0 1320
3 0 0 0 1321
4 0 0 0 1322
5 0 0 0 1323
6 0 0 751 1324
1 0 0 33 0
1 0 0 33 33
2 0 0 1326 1327
3 0 0 1328 0
4 0 0 1329 0
5 0 0 1330 0
6 0 0 1331 841
7 0 0 1325 1332
8 0 0 1319 1333
9 0 0 1310 1334
7 0 0 1279 752
8 0 0 1283 1336
7 0 0 1247 1282
8 0 0 1338 1280
9 0 0 1337 1339
10 0 0 1335 1340
11 0 0 1286 1341
12 107 0 1226 1342
8 0 0 1336 1338
9 0 0 1284 1344
8 0 0 1280 1248
9 0 0 1346 1337
10 0 0 1345 1347
1 0 0 0 34
2 0 0 1349 1349
3 0 0 1350 0
4 0 0 1351 0
5 0 0 1352 0
6 0 0 0 1353
7 0 0 1282 1354
8 0 0 1248 1355
9 0 0 1339 1356
9 0 0 1344 0
10 0 0 1357 1358
11 0 0 1348 1359
12 0 0 1360 0
13 0 0 1343 1361
6 664 682 0 0
6 695 702 0 0
7 1363 1364 0 0
6 715 734 0 0
6 780 791 0 0
7 1366 1367 0 0
8 1365 1368 0 0
6 797 0 0 0
6 805 815 0 0
7 1370 1371 0 0
6 825 829 0 0
6 0 854 0 0
7 1373 1374 0 0
8 1372 1375 0 0
9 1369 1376 0 0
6 860 866 0 0
6 872 0 0 0
7 1378 1379 0 0
6 890 893 0 0
6 921 924 0 0
7 1381 1382 0 0
8 1380 1383 0 0
6 0 933 0 0
6 938 944 0 0
7 1385 1386 0 0
6 947 0 0 0
6 978 981 0 0
7 1388 1389 0 0
8 1387 1390 0 0
9 1384 1391 0 0
10 1377 1392 0 0
6 987 989 0 0
6 0 997 0 0
7 1394 1395 0 0
6 1006 1012 0 0
6 1034 0 0 0
7 1397 1398 0 0
8 1396 1399 0 0
6 1042 1044 0 0
6 1053 1055 0 0
7 1401 1402 0 0
6 0 1071 0 0
6 1089 1100 0 0
7 1404 1405 0 0
8 1403 1406 0 0
9 1400 1407 0 0
6 1105 0 0 0
6 1114 1116 0 0
7 1409 1410 0 0
5 0 1032 0 828
6 1140 1412 0 0
2 144 1143 0 140
2 1143 145 147 0
1 21 21 0 0
2 1416 145 0 0
3 1414 1415 1417 1417
4 1418 0 0 0
5 1419 0 0 0
6 0 1420 0 0
7 1413 1421 0 0
8 1411 1422 0 0
5 1032 0 859 0
2 0 1162 0 125
2 124 126 0 1179
3 1425 1426 0 0
4 1427 0 0 0
5 0 1428 0 0
6 1424 1429 0 0
5 0 1032 0 871
6 1431 0 0 0
7 1430 1432 0 0
2 114 110 112 111
2 96 0 96 0
2 110 1211 0 0
3 1434 1435 1436 0
4 1437 0 0 0
5 1438 0 0 0
5 1032 0 892 0
6 1439 1440 0 0
5 0 1032 0 923
6 0 1442 0 0
7 1441 1443 0 0
8 1433 1444 0 0
9 1423 1445 0 0
10 1408 1446 0 0
11 1393 1447 0 0
1 0 0 24 0
2 0 1230 0 1449
1 24 24 24 24
1 0 24 0 24
2 0 1451 0 1452
3 0 1450 0 1453
4 0 1454 0 0
5 0 1455 0 0
1 0 24 24 24
1 24 24 0 24
2 1457 1458 1449 1449
2 1231 0 1449 1449
1 24 24 24 0
2 1461 1461 1461 1461
1 24 0 24 0
2 1451 1463 1451 0
3 1459 1460 1462 1464
1 0 24 0 0
1 24 24 0 0
2 1466 1467 0 0
3 1468 0 0 0
4 1465 0 1469 0
5 1470 0 0 0
6 1456 1471 0 0
5 1032 0 937 0
1 0 25 0 25
2 0 1474 0 1474
3 0 1475 0 0
4 0 1476 0 0
1 25 0 25 25
1 0 0 25 25
2 1478 1479 1479 1237
1 25 25 25 25
1 0 25 25 25
2 1481 0 1482 0
1 25 0 0 0
2 0 1484 0 0
3 1480 1483 1485 0
4 1486 0 0 0
5 1477 1487 0 0
6 1473 1488 0 0
7 1472 1489 0 0
5 0 1032 0 946
6 1491 0 0 0
5 1032 0 980 0
6 0 1493 0 0
7 1492 1494 0 0
8 1490 1495 0 0
1 26 26 26 26
2 0 0 0 1497
2 0 1497 1250 1497
3 0 1498 0 1499
2 0 1497 0 0
3 0 1501 0 0
4 0 1500 0 1502
1 0 26 26 26
1 26 0 26 26
2 1504 1505 1497 1497
2 0 0 1497 0
2 1497 1497 1497 1497
2 1497 0 1497 1251
3 1506 1507 1508 1509
1 26 26 0 0
2 1497 1497 1511 1511
2 1497 0 0 0
3 1512 1513 0 0
4 1510 0 1514 0
5 1503 1515 0 0
5 0 1032 0 988
6 1516 1517 0 0
7 1518 0 0 0
5 1032 0 1004 0
1 0 0 0 27
2 0 1521 0 1521
1 27 27 27 27
2 0 1523 0 1523
3 0 1522 0 1524
1 27 0 0 0
2 0 1526 0 0
3 0 1527 0 0
4 0 1525 0 1528
1 27 27 0 27
1 0 27 0 27
2 1530 1531 1523 1523
1 27 0 0 27
1 27 0 27 27
2 1533 0 1534 0
1 27 27 27 0
2 1523 1523 1536 1536
1 27 0 27 0
2 1523 1538 1523 1538
3 1532 1535 1537 1539
1 0 27 0 0
1 27 27 0 0
2 1541 1542 0 0
3 1543 1527 0 0
4 1540 0 1544 0
5 1529 1545 0 0
5 1005 0 0 0
6 1520 1546 1547 0
5 0 1032 0 1032
5 0 1033 0 0
6 1549 0 1550 0
7 1548 1551 0 0
8 1519 1552 0 0
9 1496 1553 0 0
5 1032 0 1032 0
5 1043 0 0 0
6 0 1555 0 1556
1 0 28 0 28
1 28 28 0 0
2 0 1558 0 1559
1 0 28 0 0
2 0 0 0 1561
3 0 1560 0 1562
4 0 1563 0 0
1 28 0 28 0
2 1565 1558 0 0
2 1565 0 1559 0
1 28 0 0 0
2 0 0 1568 0
3 1566 1567 0 1569
4 1570 0 0 0
5 1564 1571 0 0
5 0 1054 0 0
6 1572 1549 0 1573
7 1557 1574 0 0
5 1088 0 0 0
6 1555 0 1576 0
7 0 1577 0 0
8 1575 1578 0 0
6 1549 0 797 0
1 29 0 29 0
1 29 0 0 0
2 1581 1582 1582 0
2 1581 0 1582 0
1 0 29 0 0
1 29 29 0 0
2 1585 1586 0 0
3 1583 1584 1587 0
4 1588 0 0 0
5 1589 0 0 0
5 1115 0 0 0
6 1590 1555 0 1591
7 1580 1592 0 0
6 0 1549 0 829
7 1594 0 0 0
8 1593 1595 0 0
9 1579 1596 0 0
10 1554 1597 0 0
6 1555 0 860 0
1 0 30 0 0
2 0 0 0 1600
2 1288 1288 1287 1296
1 30 30 0 0
2 0 1603 0 1603
3 1601 1602 1604 1602
2 0 1600 0 0
2 1288 1288 0 1288
3 1606 1607 0 0
4 0 1605 0 1608
5 0 1609 0 0
6 1549 1610 872 0
7 1599 1611 0 0
2 1287 1296 1288 1288
3 1295 1602 1613 1602
1 30 0 0 0
2 0 0 1615 0
2 1603 0 1603 0
3 1616 0 1617 0
2 1288 1288 0 0
2 1288 1288 1288 0
3 1619 1620 1619 0
2 1615 0 0 0
3 1622 0 0 0
4 1614 1618 1621 1623
5 1624 0 0 0
6 1625 1555 0 893
1 31 0 31 0
2 0 1302 1303 1627
1 0 31 0 31
1 31 0 31 31
1 0 31 0 0
2 1629 1630 1631 1629
3 0 1628 0 1632
4 0 1633 0 0
1 31 31 0 31
1 31 31 31 0
1 31 0 0 0
2 1635 1636 1631 1637
2 1303 0 1629 1302
2 1631 1637 1303 1302
1 0 31 31 31
2 1641 1627 1627 1637
3 1638 1639 1640 1642
4 1643 0 0 0
5 1634 1644 0 0
6 1645 1549 0 924
7 1626 1646 0 0
8 1612 1647 0 0
2 0 1311 0 1311
1 0 0 0 32
2 0 1650 0 0
3 0 1649 0 1651
4 0 1652 0 0
1 0 32 0 32
1 32 32 32 32
1 32 0 0 0
1 32 0 32 0
2 1654 1655 1656 1657
1 32 0 0 32
2 1650 1313 1659 1313
1 32 32 0 32
2 1661 1655 0 0
2 1659 0 0 0
3 1658 1660 1662 1663
4 1664 0 0 0
5 1653 1665 0 0
6 1555 1666 938 0
7 0 1667 0 0
1 33 0 0 33
2 0 1669 0 1669
1 33 0 33 33
1 33 33 0 0
2 0 1671 1672 1327
3 0 1670 0 1673
2 1672 1327 0 1320
2 0 1320 0 0
3 0 1675 0 1676
4 0 1674 0 1677
5 0 1678 0 0
6 1549 1679 947 0
2 1327 1327 1327 1327
1 33 0 0 0
2 1682 0 1682 0
2 1320 1320 0 1320
1 33 0 33 0
1 0 33 33 0
2 1685 0 1686 1682
3 1681 1683 1684 1687
2 0 1320 1327 1327
2 1686 1682 0 0
2 1327 1327 0 0
3 1689 1690 1691 0
4 1688 0 1692 0
5 1693 0 0 0
6 1694 1555 0 981
7 1680 1695 0 0
8 1668 1696 0 0
9 1648 1697 0 0
6 0 1549 0 989
7 1699 0 0 0
6 1555 0 1006 0
6 1549 0 1034 0
7 1701 1702 0 0
8 1700 1703 0 0
6 0 1555 0 1044
6 0 1549 0 1055
7 1705 1706 0 0
6 1555 0 1089 0
7 0 1708 0 0
8 1707 1709 0 0
9 1704 1710 0 0
10 1698 1711 0 0
11 1598 1712 0 0
12 1448 1713 0 0
5 0 1032 0 796
6 1549 0 1715 0
6 0 1555 0 1116
7 1716 1717 0 0
6 0 1549 0 1412
7 1719 0 0 0
8 1718 1720 0 0
6 1555 0 1424 0
6 1549 0 1431 0
7 1722 1723 0 0
6 0 1555 0 1440
6 0 1549 0 1442
7 1725 1726 0 0
8 1724 1727 0 0
9 1721 1728 0 0
6 1555 0 1473 0
7 0 1730 0 0
6 1549 0 1491 0
6 0 1555 0 1493
7 1732 1733 0 0
8 1731 1734 0 0
6 0 1549 0 1517
7 1736 0 0 0
6 1555 0 1520 0
6 1549 0 1549 0
6 1547 0 0 0
6 1550 0 0 0
7 1738 1739 1740 1741
8 1737 1742 0 0
9 1735 1743 0 0
10 1729 1744 0 0
6 0 1555 0 1555
6 0 1549 0 1549
6 0 1556 0 0
6 0 1573 0 0
7 1746 1747 1748 1749
6 1555 0 1555 0
6 1576 0 0 0
7 0 1751 0 1752
8 1750 1753 0 0
6 0 1591 0 0
7 1739 1746 1370 1755
1 0 0 34 34
2 0 0 0 1757
1 34 34 0 0
1 0 0 34 0
2 1759 1760 1759 1757
3 0 1758 0 1761
4 0 1762 0 0
5 0 1763 0 0
2 1757 1757 1349 1757
2 1760 0 1349 1760
2 1349 1757 1760 1760
1 0 34 34 0
2 0 1768 1757 1768
3 1765 1766 1767 1769
1 34 0 0 0
2 1771 0 1771 0
3 0 0 1772 0
4 1770 1773 0 0
5 1774 0 0 0
6 1764 1775 0 0
6 0 829 0 0
7 1747 1776 1777 0
8 1756 1778 0 0
9 1754 1779 0 0
6 860 0 0 0
7 1751 1739 1781 1379
6 0 893 0 0
6 0 924 0 0
7 1746 1747 1783 1784
8 1782 1785 0 0
9 1786 0 0 0
10 1780 1787 0 0
11 1745 1788 0 0
12 1789 0 0 0
13 1714 1790 0 0
14 90 1362 0 1791
]]
    )
    f:close()
end
g.open(pattname)
g.show("Rule file was created: "..rulename)
