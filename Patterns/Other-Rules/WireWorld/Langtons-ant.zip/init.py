import golly as g

# switch scale to 1:1
g.setmag(0)

# change the color of state 3 to a very dark brown to make it
# easier to see the ant move and leave its droppings
g.setcolors([3,100,50,0])

# set the initial step to 28^1 to avoid becoming dizzy watching
# electrons cycle around the interior
g.setbase(28)
g.setstep(1)
