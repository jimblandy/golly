import golly as g

# switch scale to 1:1 and turn off auto-fit option so scale won't
# change when pattern starts generating
g.setmag(0)
g.setoption("autofit",False)

# change the color of state 3 to a very dark brown to make it
# easier to see the ant move and leave its droppings
g.setcolors([3,100,50,0])

# set the initial step to 28^1 to avoid becoming dizzy watching
# electrons cycle around the interior
g.setbase(28)
g.setstep(1)
